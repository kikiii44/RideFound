// Finds out why admin login fails:  pnpm admin:check
import { scryptSync, timingSafeEqual } from "node:crypto";
import "dotenv/config";
import readline from "node:readline";

const email = (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
const stored = (process.env.ADMIN_PASSWORD_HASH || "").trim();
console.log(`\n.env says ADMIN_EMAIL = "${email || "(missing)"}"`);
console.log(`.env says SITE_URL    = "${process.env.SITE_URL || "(empty)"}"  ${process.env.SITE_URL?.startsWith("https") ? "<- for testing on your computer this should be EMPTY" : ""}`);
const parts = stored.split(":");
if (parts.length !== 6 || parts[0] !== "scrypt") {
  console.log("PROBLEM: ADMIN_PASSWORD_HASH in .env is missing or damaged. Delete .env and run: pnpm setup\n");
  process.exit(1);
}
const rl = readline.createInterface({ input: process.stdin });
const lines = rl[Symbol.asyncIterator]();
const ask = async (q) => { process.stdout.write(q); const r = await lines.next(); return String(r.value ?? ""); };
const typedEmail = (await ask("Type the admin email you use to sign in: ")).trim().toLowerCase();
const typedPassword = await ask("Type the admin password (shown while typing): ");
rl.close();
const expected = Buffer.from(parts[5], "base64");
const actual = scryptSync(typedPassword, Buffer.from(parts[4], "base64"), expected.length, { N: Number(parts[1]), r: Number(parts[2]), p: Number(parts[3]) });
const passwordOk = timingSafeEqual(actual, expected);
console.log(`\nEmail matches .env:    ${typedEmail === email ? "YES" : "NO  <- type exactly the email in .env"}`);
console.log(`Password matches .env: ${passwordOk ? "YES" : "NO  <- wrong password, or it was changed. Delete .env and run: pnpm setup"}`);
if (typedEmail === email && passwordOk) console.log("\nBoth are correct. If login still fails, the problem is the browser cookie: set SITE_URL empty in .env, restart pnpm dev, and open http://localhost:3000/admin\n");
