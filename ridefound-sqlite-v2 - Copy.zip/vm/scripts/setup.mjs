// Interactive first-time setup:  pnpm setup
// Creates the .env file (admin login, site address, contact email, currency).
import { randomBytes, scryptSync } from "node:crypto";
import fs from "node:fs";
import readline from "node:readline";

if (fs.existsSync(".env")) {
  console.log("A .env file already exists. Delete it first if you want to run setup again.");
  process.exit(0);
}
const rl = readline.createInterface({ input: process.stdin });
const lines = rl[Symbol.asyncIterator]();
const ask = async (question, fallback = "", raw = false) => {
  process.stdout.write(question + (fallback ? ` [${fallback}]` : "") + ": ");
  const { value, done } = await lines.next();
  if (done) {
    console.log("\nSetup was cancelled (no more input).");
    process.exit(1);
  }
  return (raw ? String(value) : String(value).trim()) || fallback;
};

console.log("\nRidefound setup. Press Enter to accept the value in [brackets].\n");
let email = "";
while (!/^\S+@\S+\.\S+$/.test(email)) email = await ask("Admin email (you will sign in with this)");
let password = "";
while (password.length < 12) password = await ask("Admin password (at least 12 characters, it is shown while you type)", "", true);
const siteUrl = await ask("Website address when online, e.g. https://www.mysite.com (leave empty for now)");
const contact = await ask("Contact email shown on the website", email);
const currency = (await ask("Currency code for prices (USD, EUR, ...)", "USD")).toUpperCase();
rl.close();

const salt = randomBytes(16);
const hash = scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
const passwordHash = ["scrypt", 16384, 8, 1, salt.toString("base64"), hash.toString("base64")].join(":");

fs.writeFileSync(
  ".env",
  [
    `ADMIN_EMAIL=${email}`,
    `ADMIN_PASSWORD_HASH=${passwordHash}`,
    `SITE_URL=${siteUrl.replace(/\/+$/, "")}`,
    `VITE_CONTACT_EMAIL=${contact}`,
    `VITE_CURRENCY=${currency}`,
    "PORT=3000",
    "",
  ].join("\n"),
  { mode: 0o600 },
);
console.log("\nDone. Your .env file was created. Next: pnpm dev   (to test)   or   pnpm build && pnpm start   (to run for real)\n");
