// Usage: pnpm admin:hash   (prompts)   or   node scripts/hash-password.mjs "my password"
import { randomBytes, scryptSync } from "node:crypto";
import readline from "node:readline";

function hash(password) {
  const salt = randomBytes(16);
  const out = scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return ["scrypt", 16384, 8, 1, salt.toString("base64"), out.toString("base64")].join(":");
}

async function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(question, (answer) => { rl.close(); resolve(answer); }));
}

const password = process.argv[2] ?? (await ask("Choose an admin password (12+ characters): "));
if (password.length < 12) {
  console.error("Password must be at least 12 characters.");
  process.exit(1);
}
console.log("\nPut this line in your .env file:\n");
console.log(`ADMIN_PASSWORD_HASH=${hash(password)}\n`);
