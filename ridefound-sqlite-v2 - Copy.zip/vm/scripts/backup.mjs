// Backup the database and photos into backups/<date>/ :  pnpm backup
import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import "dotenv/config";

const dbFile = path.resolve(process.env.DATABASE_FILE || "./data/ridefound.db");
const uploads = path.resolve(process.env.UPLOAD_DIR || "./data/uploads");
const day = new Date().toISOString().slice(0, 10);
const target = path.resolve("backups", day);

if (!fs.existsSync(dbFile)) {
  console.error(`No database found at ${dbFile}. Nothing to back up.`);
  process.exit(1);
}
fs.mkdirSync(target, { recursive: true });
const out = path.join(target, "ridefound.db");
fs.rmSync(out, { force: true });
const db = new DatabaseSync(dbFile);
db.exec(`VACUUM INTO '${out.replace(/'/g, "''")}'`); // safe even while the site is running
db.close();
if (fs.existsSync(uploads)) fs.cpSync(uploads, path.join(target, "uploads"), { recursive: true });

// keep the 30 newest backups
const all = fs.readdirSync("backups").filter((name) => /^\d{4}-\d{2}-\d{2}$/.test(name)).sort();
for (const old of all.slice(0, Math.max(0, all.length - 30))) fs.rmSync(path.join("backups", old), { recursive: true, force: true });
console.log(`Backup saved in ${target}\nIMPORTANT: also copy the "backups" folder to another computer or cloud storage.`);
