import { useFavorites } from "@/lib/favorites";
import { useI18n } from "@/lib/i18n";
import { telHref, whatsappHref } from "@/lib/site";
import type { Vehicle } from "@/lib/vehicle-data";
import { Heart, Mail, MessageCircle, Phone } from "lucide-react";

export function StatusBadge({ status }: { status: Vehicle["status"] }) {
  const { t } = useI18n();
  if (status === "available") return null;
  const tone = status === "sold" ? "bg-[#a35745]" : "bg-[#a06d40]";
  return <span className={`rounded-full ${tone} px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.12em] text-white`}>{status === "sold" ? t("statusSold") : t("statusReserved")}</span>;
}

export function HeartButton({ id }: { id: string }) {
  const { t } = useI18n();
  const favorites = useFavorites();
  const saved = favorites.has(id);
  return (
    <button type="button" onClick={() => favorites.toggle(id)} aria-pressed={saved} aria-label={saved ? t("unsaveCar") : t("saveCar")} className="rounded-full bg-white/90 p-2.5 text-[#102b28] shadow-sm backdrop-blur transition hover:bg-white">
      <Heart size={17} fill={saved ? "currentColor" : "none"} />
    </button>
  );
}

const pill = "flex items-center justify-center gap-1.5 rounded-full px-4 py-2.5 text-xs font-bold transition";

export function ContactButtons({ vehicle, large = false }: { vehicle: Vehicle; large?: boolean }) {
  const { t } = useI18n();
  const size = large ? "py-3.5 text-sm" : "";
  return (
    <div className={`flex flex-wrap gap-2 ${large ? "" : "justify-end"}`}>
      <a href={telHref(vehicle.sellerPhone)} className={`${pill} ${size} bg-[#e4f0ec] text-[#0d6b63] hover:bg-[#d4e8e1]`}><Phone size={14} />{t("callSeller")}</a>
      <a href={whatsappHref(vehicle.sellerPhone, t("whatsappMessage", { title: vehicle.title }))} target="_blank" rel="noopener noreferrer" className={`${pill} ${size} bg-[#0d6b63] text-white hover:bg-[#09554f]`}><MessageCircle size={14} />{t("whatsapp")}</a>
      {large && vehicle.sellerEmail && <a href={`mailto:${vehicle.sellerEmail}?subject=${encodeURIComponent(vehicle.title)}`} className={`${pill} ${size} border border-[#d8d5cf] bg-white text-[#102b28] hover:border-[#0d6b63]`}><Mail size={14} />{t("emailSeller")}</a>}
    </div>
  );
}
