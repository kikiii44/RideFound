import { useI18n } from "@/lib/i18n";
import { ChevronLeft, ChevronRight, ImageOff } from "lucide-react";
import { useRef, useState, type ReactNode } from "react";

type GalleryProps = {
  images: string[];
  alt: string;
  onOpen?: () => void;
  badges?: ReactNode;
  aspect?: string;
  thumbnails?: boolean;
  priority?: boolean;
};

/** Photo viewer: always-visible arrows on touch screens, swipe, tiny-dot fix, and a graceful fallback for broken images. */
export function Gallery({ images, alt, onOpen, badges, aspect = "aspect-[1.42]", thumbnails = false, priority = false }: GalleryProps) {
  const { t, language } = useI18n();
  const rtl = language === "ar";
  const [index, setIndex] = useState(0);
  const [failed, setFailed] = useState<Set<number>>(new Set());
  const touchX = useRef<number | null>(null);
  const count = images.length;
  const go = (delta: number) => setIndex((current) => (current + delta + count) % count);
  const arrow = "absolute top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2.5 text-[#102b28] shadow-sm transition opacity-100 md:opacity-0 md:group-hover:opacity-100 focus-visible:opacity-100";
  return (
    <div>
      <div
        className={`group relative ${aspect} overflow-hidden bg-[#e9e6de]`}
        onTouchStart={(event) => { touchX.current = event.touches[0].clientX; }}
        onTouchEnd={(event) => {
          if (touchX.current === null || count < 2) return;
          const dx = event.changedTouches[0].clientX - touchX.current;
          touchX.current = null;
          if (Math.abs(dx) > 40) go((dx < 0 ? 1 : -1) * (rtl ? -1 : 1));
        }}
      >
        {failed.has(index) || !images[index] ? (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-[#8a938e]"><ImageOff size={28} /><span className="text-xs font-semibold">{t("photoUnavailable")}</span></div>
        ) : (
          <img
            src={images[index]}
            alt={`${alt} (${index + 1}/${count})`}
            loading={priority ? "eager" : "lazy"}
            decoding="async"
            onClick={onOpen}
            onError={() => setFailed((current) => new Set(current).add(index))}
            className={`h-full w-full object-cover transition duration-500 ${onOpen ? "cursor-pointer group-hover:scale-[1.03]" : ""}`}
          />
        )}
        {badges}
        {count > 1 && (
          <>
            <button type="button" onClick={() => go(-1)} aria-label={t("previousPhoto")} className={`${arrow} start-3`}>{rtl ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}</button>
            <button type="button" onClick={() => go(1)} aria-label={t("nextPhoto")} className={`${arrow} end-3`}>{rtl ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}</button>
            {!thumbnails && (
              <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 rounded-full bg-[#102b28]/55 px-1 backdrop-blur">
                {images.map((_, dot) => (
                  <button key={dot} type="button" onClick={() => setIndex(dot)} aria-label={t("viewPhoto", { number: dot + 1 })} className="p-1.5">
                    <span className={`block h-1.5 rounded-full transition-all ${dot === index ? "w-5 bg-white" : "w-1.5 bg-white/60"}`} />
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
      {thumbnails && count > 1 && (
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {images.map((image, thumb) => (
            <button key={`${image}-${thumb}`} type="button" onClick={() => setIndex(thumb)} aria-label={t("viewPhoto", { number: thumb + 1 })} className={`h-16 w-24 shrink-0 overflow-hidden rounded-lg border-2 ${thumb === index ? "border-[#0d6b63]" : "border-transparent opacity-70"}`}>
              <img src={image} alt="" loading="lazy" className="h-full w-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
