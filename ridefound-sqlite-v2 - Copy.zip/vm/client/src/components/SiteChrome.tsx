import { CONTACT_EMAIL } from "@/lib/site";
import { useI18n } from "@/lib/i18n";
import { CarFront, Menu, X } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Link } from "wouter";

export function Logo() {
  return (
    <Link href="/" className="group flex items-center gap-2.5" aria-label="Ridefound home">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#102b28] text-[#f6f3ed] shadow-[0_5px_15px_rgba(16,43,40,0.18)] transition-transform duration-200 group-hover:-rotate-6">
        <CarFront size={19} strokeWidth={2.3} />
      </span>
      <span className="font-display text-[22px] font-semibold tracking-[-0.04em] text-[#102b28]">ridefound</span>
    </Link>
  );
}

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const { t, toggleLanguage } = useI18n();
  const links = [
    { href: "/#inventory", label: t("browseCars") },
    { href: "/#how-it-works", label: t("howItWorks") },
    { href: "/#why-ridefound", label: t("whyRidefound") },
  ];
  return (
    <header className="relative z-20 border-b border-[#ebe7df] bg-[#fbfaf7]/90 backdrop-blur-xl">
      <div className="container flex h-[76px] items-center justify-between">
        <Logo />
        <nav className="hidden items-center gap-7 text-[13px] font-semibold text-[#53605b] md:flex" aria-label="Main">
          {links.map((link) => <a key={link.href} href={link.href} className="transition-colors hover:text-[#0d6b63]">{link.label}</a>)}
        </nav>
        <div className="hidden items-center gap-3 md:flex">
          <button onClick={toggleLanguage} className="rounded-full px-3 py-2.5 text-[12px] font-bold text-[#0d6b63] transition-colors hover:bg-[#e4f0ec]">{t("language")}</button>
        </div>
        <button className="rounded-xl p-2.5 text-[#102b28] md:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={t("menu")} aria-expanded={menuOpen}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>
      {menuOpen && (
        <div className="container border-t border-[#ebe7df] py-4 md:hidden">
          <nav className="flex flex-col gap-1 text-sm font-semibold text-[#53605b]">
            <button onClick={() => { toggleLanguage(); setMenuOpen(false); }} className="rounded-lg px-3 py-3 text-start text-[#0d6b63] hover:bg-[#f0eee8]">{t("language")}</button>
            {links.map((link) => <a key={link.href} onClick={() => setMenuOpen(false)} href={link.href} className="rounded-lg px-3 py-3 hover:bg-[#f0eee8]">{link.label}</a>)}
          </nav>
        </div>
      )}
    </header>
  );
}

export function Footer() {
  const { t } = useI18n();
  return (
    <footer className="border-t border-[#e7e3da] bg-[#f3f1eb]">
      <div className="container grid gap-10 py-12 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr] lg:py-16">
        <div><Logo /><p className="mt-4 max-w-xs text-sm leading-6 text-[#5f6b66]">{t("footerDescription")}</p></div>
        <div>
          <p className="mb-4 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8f5f33]">{t("explore")}</p>
          <div className="flex flex-col gap-3 text-sm text-[#53605b]">
            <a href="/#inventory" className="hover:text-[#0d6b63]">{t("browseCars")}</a>
            <a href="/#how-it-works" className="hover:text-[#0d6b63]">{t("howItWorks")}</a>
          </div>
        </div>
        <div>
          <p className="mb-4 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8f5f33]">{t("about")}</p>
          <div className="flex flex-col gap-3 text-sm text-[#53605b]">
            <a href="/#why-ridefound" className="hover:text-[#0d6b63]">{t("whyRidefound")}</a>
            <Link href="/privacy" className="hover:text-[#0d6b63]">{t("privacy")}</Link>
            <Link href="/admin" className="hover:text-[#0d6b63]">{t("adminArea")}</Link>
            <a href={`mailto:${CONTACT_EMAIL}?subject=Ridefound%20enquiry`} className="hover:text-[#0d6b63]">{t("contactUs")}</a>
          </div>
        </div>
      </div>
      <div className="container flex flex-col gap-2 border-t border-[#e1ddd3] py-5 text-xs text-[#6f7872] sm:flex-row sm:items-center sm:justify-between">
        <span>{t("footerCopyright")}</span><span>{t("catalogueListingsOnly")}</span>
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: ReactNode }) {
  return <div className="min-h-screen bg-[#fbfaf7] text-[#17221f]"><Header /><main>{children}</main><Footer /></div>;
}
