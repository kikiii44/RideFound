import { CURRENCY } from "./site";

export type Vehicle = {
  id: string;
  title: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  mileage: string;
  transmission: string;
  fuel: string;
  location: string;
  description: string;
  sellerName: string;
  sellerPhone: string;
  sellerEmail: string;
  sellerPhoto: string;
  images: string[];
  status: "available" | "reserved" | "sold";
  createdAt?: Date;
};

// Add or remove places here (and add their Arabic names in i18n.tsx -> locationNames).
export const LOCATIONS = [
  "Beirut",
  "Tripoli",
  "Sidon",
  "Tyre",
  "Jounieh",
  "Jbeil (Byblos)",
  "Zahle",
  "Baalbek",
  "Nabatieh",
  "Aley",
];

// Suggestions only: the admin can type any make or model.
export const BRANDS = ["Audi", "BMW", "Chevrolet", "Ford", "Honda", "Hyundai", "Jeep", "Kia", "Land Rover", "Mercedes-Benz", "Mitsubishi", "Nissan", "Peugeot", "Porsche", "Renault", "Toyota", "Volkswagen", "Volvo"];
export const MODELS_BY_BRAND: Record<string, string[]> = {
  Audi: ["A3", "A4", "A6", "Q3", "Q5", "Q7"],
  BMW: ["1 Series", "3 Series", "5 Series", "7 Series", "X3", "X5"],
  Ford: ["Fiesta", "Focus", "Explorer", "Mustang", "Edge"],
  Honda: ["Civic", "Accord", "CR-V", "City"],
  Hyundai: ["Accent", "Elantra", "Sonata", "Tucson", "Santa Fe"],
  Kia: ["Rio", "Cerato", "Optima", "Sportage", "Sorento"],
  "Mercedes-Benz": ["C-Class", "E-Class", "S-Class", "GLC", "GLE", "G-Class"],
  Nissan: ["Sunny", "Sentra", "Altima", "Qashqai", "X-Trail", "Patrol"],
  Toyota: ["Yaris", "Corolla", "Camry", "RAV4", "Prado", "Land Cruiser"],
  Volkswagen: ["Golf", "Jetta", "Passat", "Tiguan"],
  Volvo: ["XC40", "XC60", "XC90", "S60", "V60"],
};
export const FUEL_OPTIONS = ["Petrol", "Diesel", "Hybrid", "Electric"];
export const TRANSMISSION_OPTIONS = ["Automatic", "Manual"];

export function formatPrice(price: number, language: "en" | "ar" = "en") {
  return new Intl.NumberFormat(language === "ar" ? "ar-LB" : "en-GB", {
    style: "currency",
    currency: CURRENCY,
    maximumFractionDigits: 0,
  }).format(price);
}
