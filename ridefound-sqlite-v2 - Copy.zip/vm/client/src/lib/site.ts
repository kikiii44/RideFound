/** Site-wide settings. Override with VITE_* values in .env (they are baked in at build time). */
export const CONTACT_EMAIL = (import.meta.env.VITE_CONTACT_EMAIL as string | undefined) || "hello@example.com";
export const CURRENCY = (import.meta.env.VITE_CURRENCY as string | undefined) || "USD";

/** Digits and a leading + only, so tel: and WhatsApp links work whatever format the admin typed. */
export function cleanPhone(phone: string) {
  const trimmed = phone.trim();
  return (trimmed.startsWith("+") ? "+" : "") + trimmed.replace(/\D/g, "");
}
export const telHref = (phone: string) => `tel:${cleanPhone(phone)}`;
export const whatsappHref = (phone: string, message: string) =>
  `https://wa.me/${cleanPhone(phone).replace(/^\+/, "").replace(/^00/, "")}?text=${encodeURIComponent(message)}`;
export const carPath = (id: string) => `/car/${encodeURIComponent(id)}`;
