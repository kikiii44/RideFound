import { useCallback, useEffect, useState } from "react";

const KEY = "ridefound-favorites";

function read(): string[] {
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || "[]");
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

/** Saved cars live in this browser only (no account needed). */
export function useFavorites() {
  const [ids, setIds] = useState<string[]>(read);
  useEffect(() => {
    const sync = () => setIds(read());
    window.addEventListener("storage", sync);
    window.addEventListener("ridefound-favorites", sync);
    return () => {
      window.removeEventListener("storage", sync);
      window.removeEventListener("ridefound-favorites", sync);
    };
  }, []);
  const toggle = useCallback((id: string) => {
    const current = read();
    const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id];
    try {
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      /* storage blocked: keep in memory only */
    }
    setIds(next);
    window.dispatchEvent(new Event("ridefound-favorites"));
  }, []);
  return { ids, has: (id: string) => ids.includes(id), toggle };
}
