import { Gallery } from "@/components/Gallery";
import { PageShell } from "@/components/SiteChrome";
import { ContactButtons, HeartButton, StatusBadge } from "@/components/VehicleParts";
import { useI18n } from "@/lib/i18n";
import { trpc } from "@/lib/trpc";
import { formatPrice, type Vehicle } from "@/lib/vehicle-data";
import { AlertCircle, CarFront, MapPin, Share2 } from "lucide-react";
import { useEffect } from "react";
import { toast } from "sonner";
import { Link, useParams } from "wouter";

function Spec({ label, value }: { label: string; value: string }) {
  return <div className="rounded-xl bg-[#f7f5f0] px-4 py-3"><p className="text-[11px] font-bold uppercase tracking-[0.12em] text-[#66716c]">{label}</p><p className="mt-1 text-sm font-semibold text-[#102b28]">{value}</p></div>;
}

function Message({ icon, title, description, action }: { icon: React.ReactNode; title: string; description: string; action: React.ReactNode }) {
  return (
    <div className="container py-24 text-center">
      <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#e3efeb] text-[#0d6b63]">{icon}</span>
      <h1 className="mt-5 font-display text-3xl font-semibold text-[#102b28]">{title}</h1>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#5c6a64]">{description}</p>
      <div className="mt-6">{action}</div>
    </div>
  );
}

function Details({ vehicle }: { vehicle: Vehicle }) {
  const { t, locationLabel, optionLabel, language } = useI18n();
  useEffect(() => {
    document.title = `${vehicle.title} · Ridefound`;
    return () => { document.title = "Ridefound · Find the car that feels right"; };
  }, [vehicle.title]);
  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) { await navigator.share({ title: vehicle.title, url }); return; }
      await navigator.clipboard.writeText(url);
      toast.success(t("linkCopied"));
    } catch {
      /* share dialog dismissed */
    }
  };
  return (
    <div className="container py-8 sm:py-12">
      <Link href="/#inventory" className="text-sm font-semibold text-[#0d6b63] hover:underline">{t("backToCatalogue")}</Link>
      <div className="mt-6 grid gap-8 lg:grid-cols-[1.15fr_0.85fr]">
        <div className="overflow-hidden rounded-[24px] border border-[#e6e3dc] bg-white p-3">
          <div className="overflow-hidden rounded-[16px]">
            <Gallery
              images={vehicle.images}
              alt={vehicle.title}
              aspect="aspect-[1.4]"
              thumbnails
              priority
              badges={<div className="absolute inset-x-0 top-0 flex items-center justify-between p-4"><StatusBadge status={vehicle.status} /><span className="ms-auto"><HeartButton id={vehicle.id} /></span></div>}
            />
          </div>
        </div>
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#8f5f33]">{vehicle.year} · {vehicle.brand}</p>
          <h1 className="mt-1 font-display text-4xl font-semibold leading-[1.05] tracking-[-0.04em] text-[#102b28]">{vehicle.title.replace(`${vehicle.year} `, "")}</h1>
          <p className="mt-3 font-display text-3xl font-semibold text-[#102b28]">{formatPrice(vehicle.price, language)}</p>
          <p className="mt-2 flex items-center gap-1.5 text-sm text-[#5c6a64]"><MapPin size={14} />{locationLabel(vehicle.location)}</p>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <Spec label={t("year")} value={String(vehicle.year)} />
            <Spec label={t("mileage")} value={vehicle.mileage} />
            <Spec label={t("transmission")} value={optionLabel(vehicle.transmission)} />
            {vehicle.fuel && <Spec label={t("fuel")} value={optionLabel(vehicle.fuel)} />}
          </div>
          <p className="mt-6 whitespace-pre-line text-[15px] leading-7 text-[#3f4d47]">{vehicle.description}</p>
          <div className="mt-8 rounded-2xl border border-[#e4e1d9] bg-white p-5">
            <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#66716c]">{t("sellerLabel")}</p>
            <p className="mt-1 font-semibold text-[#102b28]">{vehicle.sellerName}</p>
            <p dir="ltr" className="mt-0.5 text-start text-sm text-[#5c6a64]">{vehicle.sellerPhone}</p>
            {vehicle.status === "sold" ? <p className="mt-4 text-sm font-semibold text-[#a35745]">{t("statusSold")}</p> : <div className="mt-4"><ContactButtons vehicle={vehicle} large /></div>}
          </div>
          <button type="button" onClick={() => void share()} className="mt-4 flex items-center gap-2 rounded-full border border-[#d8d5cf] bg-white px-4 py-2.5 text-xs font-bold text-[#53605b] hover:border-[#0d6b63]"><Share2 size={14} />{t("copyLink")}</button>
        </div>
      </div>
    </div>
  );
}

export default function CarPage() {
  const { t } = useI18n();
  const { id = "" } = useParams<{ id: string }>();
  const query = trpc.vehicle.get.useQuery({ id }, { enabled: Boolean(id) });
  let body;
  if (query.isLoading) body = <div className="container py-32 text-center text-[#5c6a64]">{t("loadingCatalogue")}</div>;
  else if (query.isError) body = <Message icon={<AlertCircle size={25} />} title={t("catalogueErrorTitle")} description={t("catalogueErrorDescription")} action={<button onClick={() => void query.refetch()} className="rounded-full bg-[#102b28] px-5 py-3 text-sm font-bold text-white">{t("retry")}</button>} />;
  else if (!query.data) body = <Message icon={<CarFront size={25} />} title={t("carNotFoundTitle")} description={t("carNotFoundDescription")} action={<Link href="/#inventory" className="rounded-full bg-[#102b28] px-5 py-3 text-sm font-bold text-white">{t("browseCars")}</Link>} />;
  else body = <Details vehicle={query.data as Vehicle} />;
  return <PageShell>{body}</PageShell>;
}
