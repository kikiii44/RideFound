import { PageShell } from "@/components/SiteChrome";
import { useI18n } from "@/lib/i18n";

export default function Privacy() {
  const { t } = useI18n();
  return (
    <PageShell>
      <div className="container max-w-2xl py-16">
        <h1 className="font-display text-4xl font-semibold tracking-[-0.04em] text-[#102b28]">{t("privacyTitle")}</h1>
        <div className="mt-6 space-y-4 text-[15px] leading-7 text-[#3f4d47]">
          <p>{t("privacyIntro")}</p>
          <p>{t("privacyListings")}</p>
          <p>{t("privacyStorage")}</p>
          <p>{t("privacyContact")}</p>
        </div>
      </div>
    </PageShell>
  );
}
