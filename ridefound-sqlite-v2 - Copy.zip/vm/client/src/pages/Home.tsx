import { Footer, Header } from "@/components/SiteChrome";
import { Gallery } from "@/components/Gallery";
import { ContactButtons, HeartButton, StatusBadge } from "@/components/VehicleParts";
import { useFavorites } from "@/lib/favorites";
import { useI18n } from "@/lib/i18n";
import { carPath } from "@/lib/site";
import { trpc } from "@/lib/trpc";
import { BRANDS, formatPrice, FUEL_OPTIONS, LOCATIONS, TRANSMISSION_OPTIONS, type Vehicle } from "@/lib/vehicle-data";
import {
  AlertCircle,
  ArrowDownUp,
  ArrowRight,
  CarFront,
  Check,
  ChevronDown,
  Heart,
  MapPin,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";

const inputClass =
  "h-11 w-full rounded-xl border border-[#d8d5cf] bg-white px-3.5 text-sm text-[#17221f] outline-none transition placeholder:text-[#7a807b] focus:border-[#0d6b63] focus:ring-4 focus:ring-[#0d6b63]/10";

function SearchBar({ value, onChange, onSubmit }: { value: string; onChange: (value: string) => void; onSubmit: () => void }) {
  const { t } = useI18n();
  return (
    <form onSubmit={(event) => { event.preventDefault(); onSubmit(); }} className="flex w-full items-center gap-2 rounded-2xl border border-[#d9ded8] bg-white p-2 shadow-[0_16px_45px_rgba(31,53,47,0.13)] transition focus-within:border-[#0d6b63] focus-within:ring-4 focus-within:ring-[#0d6b63]/10">
      <Search className="ms-3 shrink-0 text-[#73827c]" size={19} />
      <input aria-label={t("searchCars")} value={value} onChange={(event) => onChange(event.currentTarget.value)} placeholder={t("searchPlaceholder")} className="h-11 min-w-0 flex-1 bg-transparent px-2 text-sm text-[#17221f] outline-none placeholder:text-[#7a847e]" />
      <button type="submit" className="hidden rounded-xl bg-[#0d6b63] px-5 py-3 text-sm font-semibold text-white transition-all hover:-translate-y-0.5 hover:bg-[#09554f] sm:block">{t("searchCars")}</button>
      <button type="submit" aria-label={t("searchCars")} className="rounded-xl bg-[#0d6b63] p-3 text-white sm:hidden"><ArrowRight size={17} /></button>
    </form>
  );
}

function FilterSelect({ label, value, onChange, options, placeholder }: { label: string; value: string; onChange: (value: string) => void; options: string[]; placeholder: string }) {
  const { optionLabel } = useI18n();
  return (
    <label className="block">
      <span className="mb-2 block text-[11px] font-bold uppercase tracking-[0.14em] text-[#66716c]">{label}</span>
      <span className="relative block">
        <select value={value} onChange={(event) => onChange(event.currentTarget.value)} className={`${inputClass} appearance-none pe-9`}>
          <option value="">{placeholder}</option>
          {options.map((option) => <option value={option} key={option}>{optionLabel(option)}</option>)}
        </select>
        <ChevronDown size={16} className="pointer-events-none absolute end-3 top-3.5 text-[#66716c]" />
      </span>
    </label>
  );
}

function RangeFilter({ label, min, max, onMinChange, onMaxChange, minLabel, maxLabel, minPlaceholder, maxPlaceholder, hint, error }: { label: string; min: string; max: string; onMinChange: (value: string) => void; onMaxChange: (value: string) => void; minLabel: string; maxLabel: string; minPlaceholder: string; maxPlaceholder: string; hint: string; error: string }) {
  const invalidRange = min !== "" && max !== "" && Number(min) > Number(max);
  return (
    <div>
      <span className="mb-2 block text-[11px] font-bold uppercase tracking-[0.14em] text-[#66716c]">{label}</span>
      <div className="grid grid-cols-2 gap-2">
        <label className="relative block"><span className="sr-only">{minLabel}</span><input type="number" min="0" value={min} onChange={(event) => onMinChange(event.currentTarget.value)} className={`${inputClass} pr-2 text-[12px]`} placeholder={minPlaceholder} aria-label={minLabel} /></label>
        <label className="relative block"><span className="sr-only">{maxLabel}</span><input type="number" min="0" value={max} onChange={(event) => onMaxChange(event.currentTarget.value)} className={`${inputClass} pr-2 text-[12px]`} placeholder={maxPlaceholder} aria-label={maxLabel} /></label>
      </div>
      <p className={`mt-2 text-[11px] leading-4 ${invalidRange ? "text-[#a35745]" : "text-[#667068]"}`}>{invalidRange ? error : hint}</p>
    </div>
  );
}

function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  const { t, locationLabel, language } = useI18n();
  const [, navigate] = useLocation();
  const open = () => navigate(carPath(vehicle.id));
  return (
    <article className={`group overflow-hidden rounded-[22px] border border-[#e6e3dc] bg-white shadow-[0_12px_35px_rgba(36,53,48,0.055)] transition duration-300 hover:-translate-y-1 hover:shadow-[0_20px_45px_rgba(36,53,48,0.12)] ${vehicle.status === "sold" ? "opacity-80" : ""}`}>
      <Gallery
        images={vehicle.images}
        alt={vehicle.title}
        onOpen={open}
        badges={
          <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between p-4">
            <div className="pointer-events-auto">
              {vehicle.status === "available" ? <span className="rounded-full bg-[#102b28]/85 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.12em] text-white backdrop-blur">{t("catalogueListing")}</span> : <StatusBadge status={vehicle.status} />}
            </div>
            <div className="pointer-events-auto"><HeartButton id={vehicle.id} /></div>
          </div>
        }
      />
      <div className="p-5 sm:p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.14em] text-[#8f5f33]">{vehicle.year} · {vehicle.brand}</p>
            <h3 className="font-display text-[23px] font-semibold leading-[1.1] tracking-[-0.03em] text-[#102b28]"><Link href={carPath(vehicle.id)} className="hover:text-[#0d6b63]">{vehicle.title.replace(`${vehicle.year} `, "")}</Link></h3>
          </div>
          <p className="shrink-0 text-end font-display text-[20px] font-semibold text-[#102b28]">{formatPrice(vehicle.price, language)}</p>
        </div>
        <p className="mt-4 line-clamp-2 text-sm leading-6 text-[#5c6a64]">{vehicle.description}</p>
        <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 border-y border-[#efede8] py-4 text-[12px] font-semibold text-[#5c6a64]"><span>{vehicle.mileage}</span><span>{vehicle.transmission}</span>{vehicle.fuel && <span>{vehicle.fuel}</span>}</div>
        <div className="mt-4 flex items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            {vehicle.sellerPhoto ? <img src={vehicle.sellerPhoto} alt="" loading="lazy" className="h-8 w-8 rounded-full object-cover ring-2 ring-[#f1eee7]" /> : <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[#e4f0ec] text-xs font-bold text-[#0d6b63]">{vehicle.sellerName.slice(0, 1).toUpperCase()}</span>}
            <div className="min-w-0"><p className="truncate text-xs font-bold text-[#102b28]">{vehicle.sellerName}</p><p className="flex items-center gap-1 text-[11px] text-[#66706a]"><MapPin size={11} />{locationLabel(vehicle.location)}</p></div>
          </div>
          <Link href={carPath(vehicle.id)} className="flex shrink-0 items-center gap-1 text-xs font-bold text-[#0d6b63] hover:underline">{t("viewDetails")} <ArrowRight size={13} className="directional-arrow" /></Link>
        </div>
        {vehicle.status !== "sold" && <div className="mt-4 border-t border-[#efede8] pt-4"><ContactButtons vehicle={vehicle} /></div>}
      </div>
    </article>
  );
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  const { t } = useI18n();
  return (
    <div className="col-span-full rounded-[24px] border border-dashed border-[#e3c9c0] bg-[#fff8f5] px-6 py-16 text-center">
      <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#fbe9e3] text-[#a35745]"><AlertCircle size={25} /></span>
      <h3 className="mt-5 font-display text-2xl font-semibold text-[#102b28]">{t("catalogueErrorTitle")}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#5c6a64]">{t("catalogueErrorDescription")}</p>
      <button onClick={onRetry} className="mt-6 rounded-full bg-[#102b28] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#0d6b63]">{t("retry")}</button>
    </div>
  );
}

function EmptyState({ hasFilters, onReset, loading }: { hasFilters: boolean; onReset: () => void; loading?: boolean }) {
  const { t } = useI18n();
  return <div className="col-span-full rounded-[24px] border border-dashed border-[#cdd7d1] bg-[#f7faf7] px-6 py-16 text-center"><span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#e3efeb] text-[#0d6b63]"><CarFront size={25} /></span><h3 className="mt-5 font-display text-2xl font-semibold text-[#102b28]">{loading ? t("loadingCatalogue") : hasFilters ? t("noMatchTitle") : t("emptyTitle")}</h3><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#5c6a64]">{loading ? t("loadingCatalogueDescription") : hasFilters ? t("noMatchDescription") : t("emptyDescription")}</p>{hasFilters && !loading && <button onClick={onReset} className="mt-6 rounded-full bg-[#102b28] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#0d6b63]">{t("clearFilters")}</button>}</div>;
}

function numberFromMileage(value: string) {
  const parsed = Number(value.replace(/[^0-9]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

function HomeView() {
  const { t } = useI18n();
  const { data: vehicles = [], isLoading, isError, refetch } = trpc.vehicle.list.useQuery();
  const favorites = useFavorites();
  const [savedOnly, setSavedOnly] = useState(false);
  const initial = useMemo(() => new URLSearchParams(typeof window === "undefined" ? "" : window.location.search), []);
  const [search, setSearch] = useState(initial.get("q") ?? "");
  const [brand, setBrand] = useState(initial.get("brand") ?? "");
  const [location, setSelectedLocation] = useState(initial.get("loc") ?? "");
  const [fuel, setFuel] = useState(initial.get("fuel") ?? "");
  const [transmission, setTransmission] = useState(initial.get("gear") ?? "");
  const [minPrice, setMinPrice] = useState(initial.get("minPrice") ?? "");
  const [maxPrice, setMaxPrice] = useState(initial.get("maxPrice") ?? "");
  const [minYear, setMinYear] = useState(initial.get("minYear") ?? "");
  const [maxYear, setMaxYear] = useState(initial.get("maxYear") ?? "");
  const [minMileage, setMinMileage] = useState(initial.get("minKm") ?? "");
  const [maxMileage, setMaxMileage] = useState(initial.get("maxKm") ?? "");
  const [sort, setSort] = useState(initial.get("sort") ?? "newest");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const priceRangeInvalid = minPrice !== "" && maxPrice !== "" && Number(minPrice) > Number(maxPrice);
  const yearRangeInvalid = minYear !== "" && maxYear !== "" && Number(minYear) > Number(maxYear);
  const mileageRangeInvalid = minMileage !== "" && maxMileage !== "" && Number(minMileage) > Number(maxMileage);

  useEffect(() => {
    const params = new URLSearchParams();
    const entries: Record<string, string> = { q: search, brand, loc: location, fuel, gear: transmission, minPrice, maxPrice, minYear, maxYear, minKm: minMileage, maxKm: maxMileage };
    Object.entries(entries).forEach(([key, value]) => { if (value) params.set(key, value); });
    if (sort !== "newest") params.set("sort", sort);
    const query = params.toString();
    window.history.replaceState(null, "", `${window.location.pathname}${query ? `?${query}` : ""}${window.location.hash}`);
  }, [search, brand, location, fuel, transmission, minPrice, maxPrice, minYear, maxYear, minMileage, maxMileage, sort]);

  const brandOptions = useMemo(() => (vehicles.length ? Array.from(new Set(vehicles.map((vehicle) => vehicle.brand))).sort() : BRANDS), [vehicles]);
  const locationOptions = useMemo(() => (vehicles.length ? Array.from(new Set(vehicles.map((vehicle) => vehicle.location))).sort() : LOCATIONS), [vehicles]);

  const filteredVehicles = useMemo(() => {
    const query = search.toLowerCase().trim();
    const result = vehicles.filter((vehicle) => {
      const matchesSearch = !query || [vehicle.title, vehicle.brand, vehicle.model, vehicle.description, vehicle.location].some((value) => value.toLowerCase().includes(query));
      const matchesPrice = !priceRangeInvalid && (minPrice === "" || vehicle.price >= Number(minPrice)) && (maxPrice === "" || vehicle.price <= Number(maxPrice));
      const matchesYear = !yearRangeInvalid && (minYear === "" || vehicle.year >= Number(minYear)) && (maxYear === "" || vehicle.year <= Number(maxYear));
      const mileage = numberFromMileage(vehicle.mileage);
      const matchesMileage = !mileageRangeInvalid && (minMileage === "" || mileage >= Number(minMileage)) && (maxMileage === "" || mileage <= Number(maxMileage));
      return matchesSearch && (!savedOnly || favorites.ids.includes(vehicle.id)) && (!brand || vehicle.brand.toLowerCase() === brand.toLowerCase()) && (!location || vehicle.location.toLowerCase() === location.toLowerCase()) && (!fuel || vehicle.fuel.toLowerCase() === fuel.toLowerCase()) && (!transmission || vehicle.transmission.toLowerCase() === transmission.toLowerCase()) && matchesPrice && matchesYear && matchesMileage;
    });
    return [...result].sort((a, b) => Number(a.status === "sold") - Number(b.status === "sold") || (sort === "price-low" ? a.price - b.price : sort === "price-high" ? b.price - a.price : 0));
  }, [vehicles, search, brand, location, fuel, transmission, minPrice, maxPrice, minYear, maxYear, minMileage, maxMileage, priceRangeInvalid, yearRangeInvalid, mileageRangeInvalid, sort, savedOnly, favorites.ids]);

  const hasFilters = Boolean(savedOnly || search || brand || location || fuel || transmission || minPrice || maxPrice || minYear || maxYear || minMileage || maxMileage);
  const clearFilters = () => { setSavedOnly(false); setSearch(""); setBrand(""); setSelectedLocation(""); setFuel(""); setTransmission(""); setMinPrice(""); setMaxPrice(""); setMinYear(""); setMaxYear(""); setMinMileage(""); setMaxMileage(""); };
  const filterCount = [brand, location, fuel, transmission, minPrice, maxPrice, minYear, maxYear, minMileage, maxMileage].filter(Boolean).length;

  const filterPanel = <div className="space-y-5"><FilterSelect label={t("make")} value={brand} onChange={setBrand} options={brandOptions} placeholder={t("allMakes")} /><FilterSelect label={t("location")} value={location} onChange={setSelectedLocation} options={locationOptions} placeholder={t("everywhere")} /><FilterSelect label={t("fuel")} value={fuel} onChange={setFuel} options={FUEL_OPTIONS} placeholder={t("allFuelTypes")} /><FilterSelect label={t("transmission")} value={transmission} onChange={setTransmission} options={TRANSMISSION_OPTIONS} placeholder={t("allTransmissions")} /><RangeFilter label={t("price")} min={minPrice} max={maxPrice} onMinChange={setMinPrice} onMaxChange={setMaxPrice} minLabel={t("minPrice")} maxLabel={t("maxPrice")} minPlaceholder={t("minPricePlaceholder")} maxPlaceholder={t("maxPricePlaceholder")} hint={t("budgetHint")} error={t("priceRangeError")} /><RangeFilter label={t("yearRange")} min={minYear} max={maxYear} onMinChange={setMinYear} onMaxChange={setMaxYear} minLabel={t("minYear")} maxLabel={t("maxYear")} minPlaceholder={t("minYearPlaceholder")} maxPlaceholder={t("maxYearPlaceholder")} hint={t("yearHint")} error={t("yearRangeError")} /><RangeFilter label={t("mileageRange")} min={minMileage} max={maxMileage} onMinChange={setMinMileage} onMaxChange={setMaxMileage} minLabel={t("minMileage")} maxLabel={t("maxMileage")} minPlaceholder={t("minMileagePlaceholder")} maxPlaceholder={t("maxMileagePlaceholder")} hint={t("mileageHint")} error={t("mileageRangeError")} /></div>;

  return <div className="min-h-screen bg-[#fbfaf7] text-[#17221f]"><Header /><main><section className="relative overflow-hidden border-b border-[#e3e1d9] bg-[#dfeae5]"><div className="absolute -right-24 -top-28 h-[420px] w-[420px] rounded-full bg-[#f1cc9e]/60 blur-3xl" /><div className="absolute bottom-0 left-[35%] h-40 w-80 rounded-full bg-[#9ac2b3]/40 blur-3xl" /><div className="container relative grid items-center gap-10 py-14 sm:py-20 lg:grid-cols-[0.93fr_1.07fr] lg:gap-16 lg:py-[88px]"><div className="max-w-xl"><div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#a9c8bb] bg-white/55 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-[#0d6b63]"><Sparkles size={13} />{t("heroBadge")}</div><h1 className="font-display text-[48px] font-semibold leading-[0.96] tracking-[-0.065em] text-[#102b28] sm:text-[65px]">{t("heroTitle")}<br /><em className="font-serif font-normal text-[#8f5f33]">{t("heroTitleEmphasis")}</em></h1><p className="mt-6 max-w-md text-[15px] leading-7 text-[#51625c]">{t("heroDescription")}</p><div className="mt-8 max-w-xl"><SearchBar value={search} onChange={setSearch} onSubmit={() => document.getElementById("inventory")?.scrollIntoView({ behavior: "smooth" })} /><div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] font-semibold text-[#61736c]"><span className="flex items-center gap-1.5"><ShieldCheck size={14} className="text-[#0d6b63]" /> {t("curatedListings")}</span><span className="flex items-center gap-1.5"><MapPin size={14} className="text-[#0d6b63]" /> {t("locationsCount", { count: locationOptions.length })}</span></div></div></div><div className="relative mx-auto w-full max-w-[600px] lg:ms-auto"><div className="relative aspect-[1.18] overflow-hidden rounded-[30px] bg-[#153934] shadow-[0_28px_70px_rgba(25,55,48,0.22)]"><img src="https://images.unsplash.com/photo-1504215680853-026ed2a45def?auto=format&fit=crop&w=1200&q=85" alt="A car driving through the countryside" className="h-full w-full object-cover opacity-90" /><div className="absolute inset-0 bg-gradient-to-tr from-[#102b28]/70 via-[#102b28]/5 to-transparent" /><div className="absolute bottom-6 left-6 right-6 flex items-end justify-between text-white"><div><p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#dcb98f]">{t("heroRouteLabel")}</p><p className="mt-1 font-display text-2xl font-semibold tracking-[-0.04em]">{t("heroRouteTitle")}</p></div><span className="flex h-11 w-11 items-center justify-center rounded-full border border-white/30 bg-white/15 backdrop-blur"><ArrowRight size={19} /></span></div></div><div className="absolute -bottom-5 -start-3 flex items-center gap-3 rounded-2xl border border-white bg-[#fffdf9] px-4 py-3 shadow-[0_14px_28px_rgba(25,55,48,0.16)] sm:-start-7"><span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#e4f0ec] text-[#0d6b63]"><Check size={17} strokeWidth={3} /></span><div><p className="text-[12px] font-bold text-[#102b28]">{t("clearDetails")}</p><p className="text-[11px] text-[#66716c]">{t("clearDetailsDescription")}</p></div></div></div></div></section><section id="inventory" className="container scroll-mt-8 py-16 sm:py-20 lg:py-24"><div className="flex flex-col justify-between gap-5 border-b border-[#e4e1d9] pb-7 sm:flex-row sm:items-end"><div><p className="mb-2 text-[11px] font-bold uppercase tracking-[0.16em] text-[#8f5f33]">{t("collectionEyebrow")}</p><h2 className="font-display text-4xl font-semibold tracking-[-0.055em] text-[#102b28] sm:text-[46px]">{t("collectionTitle")}</h2></div><p className="max-w-xs text-sm leading-6 text-[#5c6a64] sm:text-end">{t("collectionDescription")}</p></div><div className="mt-8 grid gap-8 lg:grid-cols-[236px_1fr]"><aside className="hidden lg:block"><div className="sticky top-6 rounded-2xl border border-[#e4e1d9] bg-[#f7f5f0] p-5"><div className="mb-5 flex items-center justify-between"><h3 className="font-display text-xl font-semibold text-[#102b28]">{t("refine")}</h3>{hasFilters && <button onClick={clearFilters} className="text-[11px] font-bold text-[#0d6b63] hover:underline">{t("reset")}</button>}</div>{filterPanel}<div className="mt-7 border-t border-[#e1ddd3] pt-5"><p className="mb-2 text-[11px] font-bold uppercase tracking-[0.14em] text-[#66716c]">{t("yourPlaces")}</p><p className="text-xs leading-5 text-[#66716c]">{t("placesDescription")}</p></div></div></aside><div className="min-w-0"><div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-2 lg:hidden"><button onClick={() => setFiltersOpen(!filtersOpen)} className="flex w-fit items-center gap-2 rounded-full border border-[#d8d5cf] bg-white px-4 py-2.5 text-xs font-bold text-[#53605b]"><SlidersHorizontal size={15} />{t("filters")} {filterCount > 0 && <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#0d6b63] text-[10px] text-white">{filterCount}</span>}</button>{hasFilters && <button onClick={clearFilters} className="rounded-full border border-[#d8d5cf] bg-white px-4 py-2.5 text-xs font-bold text-[#0d6b63]">{t("clearFilters")}</button>}</div><div className="flex items-center justify-between gap-3 sm:ms-auto"><p className="text-sm text-[#5c6a64]">{isError ? t("catalogueUnavailable") : filteredVehicles.length === 1 ? t("availableCar", { count: 1 }) : t("availableCars", { count: filteredVehicles.length })}</p><button type="button" onClick={() => setSavedOnly(!savedOnly)} aria-pressed={savedOnly} className={`flex h-10 items-center gap-1.5 rounded-full border px-4 text-xs font-bold ${savedOnly ? "border-[#0d6b63] bg-[#e4f0ec] text-[#0d6b63]" : "border-[#d8d5cf] bg-white text-[#53605b]"}`}><Heart size={14} fill={savedOnly ? "currentColor" : "none"} />{t("savedCars")} ({favorites.ids.length})</button><label className="relative"><span className="sr-only">{t("sortCars")}</span><select value={sort} onChange={(event) => setSort(event.currentTarget.value)} className="h-10 appearance-none rounded-full border border-[#d8d5cf] bg-white ps-4 pe-9 text-xs font-bold text-[#53605b] outline-none focus:border-[#0d6b63]"><option value="newest">{t("newestFirst")}</option><option value="price-low">{t("priceLow")}</option><option value="price-high">{t("priceHigh")}</option></select><ArrowDownUp size={14} className="pointer-events-none absolute end-3 top-3 text-[#66716c]" /></label></div></div>{filtersOpen && <div className="mb-6 rounded-2xl border border-[#e4e1d9] bg-[#f7f5f0] p-4 lg:hidden">{filterPanel}</div>}<div className="grid gap-6 md:grid-cols-2">{isError ? <ErrorState onRetry={() => void refetch()} /> : filteredVehicles.length ? filteredVehicles.map((vehicle) => <VehicleCard key={vehicle.id} vehicle={vehicle} />) : savedOnly && !isLoading && favorites.ids.length === 0 ? <div className="col-span-full rounded-[24px] border border-dashed border-[#cdd7d1] bg-[#f7faf7] px-6 py-16 text-center"><h3 className="font-display text-2xl font-semibold text-[#102b28]">{t("noSavedTitle")}</h3><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#5c6a64]">{t("noSavedDescription")}</p></div> : <EmptyState hasFilters={hasFilters} onReset={clearFilters} loading={isLoading} />}</div></div></div></section><section id="how-it-works" className="border-y border-[#e4e1d9] bg-[#f3f1eb] scroll-mt-8"><div className="container grid gap-10 py-16 sm:py-20 lg:grid-cols-[0.8fr_1.2fr] lg:py-24"><div><p className="mb-2 text-[11px] font-bold uppercase tracking-[0.16em] text-[#8f5f33]">{t("simpleEyebrow")}</p><h2 className="max-w-sm font-display text-4xl font-semibold leading-[1.03] tracking-[-0.055em] text-[#102b28]">{t("simpleTitle")}</h2></div><div className="grid gap-8 sm:grid-cols-3"><div><span className="font-display text-3xl text-[#8f5f33]">01</span><h3 className="mt-3 font-semibold text-[#102b28]">{t("step1Title")}</h3><p className="mt-2 text-sm leading-6 text-[#5c6a64]">{t("step1Description")}</p></div><div><span className="font-display text-3xl text-[#8f5f33]">02</span><h3 className="mt-3 font-semibold text-[#102b28]">{t("step2Title")}</h3><p className="mt-2 text-sm leading-6 text-[#5c6a64]">{t("step2Description")}</p></div><div><span className="font-display text-3xl text-[#8f5f33]">03</span><h3 className="mt-3 font-semibold text-[#102b28]">{t("step3Title")}</h3><p className="mt-2 text-sm leading-6 text-[#5c6a64]">{t("step3Description")}</p></div></div></div></section><section id="why-ridefound" className="container scroll-mt-8 py-16 sm:py-20"><div className="flex flex-col items-start justify-between gap-6 rounded-[28px] bg-[#102b28] px-7 py-10 text-white sm:px-12 sm:py-14 lg:flex-row lg:items-end"><div className="max-w-xl"><p className="mb-3 text-[11px] font-bold uppercase tracking-[0.16em] text-[#dcb98f]">{t("whyEyebrow")}</p><h2 className="font-display text-4xl font-semibold leading-none tracking-[-0.05em] sm:text-5xl">{t("whyTitle").split("\n")[0]}<br /><span className="text-[#a8cabc]">{t("whyTitle").split("\n")[1]}</span></h2><p className="mt-5 max-w-md text-sm leading-6 text-[#c1d0ca]">{t("whyDescription")}</p></div><a href="#inventory" className="flex items-center gap-2 rounded-full bg-[#dcb98f] px-5 py-3.5 text-sm font-bold text-[#102b28] transition hover:bg-[#edcda8]">{t("browseCollection")} <ArrowRight size={16} /></a></div></section></main><Footer /></div>;
}


export default function Home() { return <HomeView />; }
