import { Logo } from "@/components/SiteChrome";
import { useAdmin } from "@/hooks/useAdmin";
import { useI18n } from "@/lib/i18n";
import { CURRENCY } from "@/lib/site";
import { trpc } from "@/lib/trpc";
import { BRANDS, formatPrice, FUEL_OPTIONS, LOCATIONS, MODELS_BY_BRAND, TRANSMISSION_OPTIONS, type Vehicle } from "@/lib/vehicle-data";
import { AlertCircle, CarFront, Check, Download, Edit3, MoveDown, MoveUp, Plus, RefreshCcw, ShieldCheck, Trash2, Upload, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

const inputClass =
  "h-11 w-full rounded-xl border border-[#d8d5cf] bg-white px-3.5 text-sm text-[#17221f] outline-none transition placeholder:text-[#7a807b] focus:border-[#0d6b63] focus:ring-4 focus:ring-[#0d6b63]/10";
const textareaClass =
  "min-h-28 w-full rounded-xl border border-[#d8d5cf] bg-white px-3.5 py-3 text-sm text-[#17221f] outline-none transition placeholder:text-[#7a807b] focus:border-[#0d6b63] focus:ring-4 focus:ring-[#0d6b63]/10";

const blankVehicle: Vehicle = {
  id: "", title: "", brand: "", model: "", year: new Date().getFullYear(), price: 0, mileage: "",
  transmission: TRANSMISSION_OPTIONS[0], fuel: FUEL_OPTIONS[0], location: LOCATIONS[0], description: "",
  sellerName: "", sellerPhone: "", sellerEmail: "", sellerPhoto: "", images: [], status: "available",
};

function errorCode(error: unknown): string {
  return (error as { data?: { code?: string } } | null)?.data?.code ?? "";
}

// ---------- photo helpers ----------
const MAX_SIDE = 1600;
const MAX_SOURCE_BYTES = 25 * 1024 * 1024;

function blobAsBase64(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = () => reject(reader.error || new Error("Unable to read file"));
    reader.readAsDataURL(blob);
  });
}

/** Shrinks big phone photos to WebP (max 1600px) before upload: much faster pages for visitors. */
async function prepareImage(file: File): Promise<string> {
  if (file.type === "image/gif") return blobAsBase64(file);
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, MAX_SIDE / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas unavailable");
    context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", 0.82));
    if (!blob || blob.type !== "image/webp" || (scale === 1 && blob.size >= file.size)) return blobAsBase64(file);
    return blobAsBase64(blob);
  } catch {
    return blobAsBase64(file);
  }
}

function imageLoads(url: string) {
  return new Promise<boolean>((resolve) => {
    const image = new Image();
    const timeout = window.setTimeout(() => { image.src = ""; resolve(false); }, 8000);
    image.onload = () => { window.clearTimeout(timeout); resolve(true); };
    image.onerror = () => { window.clearTimeout(timeout); resolve(false); };
    image.src = url;
  });
}

function phoneLooksValid(value: string) {
  return /^\+?[0-9\s().-]+$/.test(value.trim()) && value.replace(/\D/g, "").length >= 7;
}

// ---------- photo manager ----------
function PhotoManager({ images, onChange, onUpload, uploading }: { images: string[]; onChange: (images: string[]) => void; onUpload: (files: FileList, replaceIndex?: number) => Promise<void>; uploading: boolean }) {
  const { t } = useI18n();
  const [broken, setBroken] = useState<number[]>([]);
  const move = (index: number, direction: -1 | 1) => {
    const target = index + direction;
    if (target < 0 || target >= images.length) return;
    const next = [...images];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
    setBroken([]);
  };
  const accept = "image/jpeg,image/png,image/webp,image/gif";
  return (
    <div className="rounded-2xl border border-[#e4e1d9] bg-[#f7f5f0] p-4 sm:col-span-2">
      <div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-start">
        <div><span className="field-label">{t("carPhotos")}</span><p className="text-xs leading-5 text-[#66716c]">{t("photoManagerHelp")}</p></div>
        <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-[#cfdad4] bg-white px-3 py-2 text-xs font-bold text-[#0d6b63] hover:border-[#0d6b63]">
          <Upload size={14} />{t("addPhotos")}
          <input type="file" multiple accept={accept} className="sr-only" disabled={uploading} onChange={(event) => { if (event.currentTarget.files) void onUpload(event.currentTarget.files); event.currentTarget.value = ""; }} />
        </label>
      </div>
      {images.length === 0 ? (
        <p className="mt-4 rounded-xl border border-dashed border-[#cfdad4] px-4 py-5 text-center text-xs text-[#66716c]">{t("noPhotosYet")}</p>
      ) : (
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {images.map((image, index) => (
            <div key={`${image}-${index}`} className="overflow-hidden rounded-xl border border-[#dfe5df] bg-white">
              <div className="relative aspect-[1.4] bg-[#e9e6de]">
                <img src={image} alt={t("photoNumber", { number: index + 1 })} onError={() => setBroken((current) => (current.includes(index) ? current : [...current, index]))} className="h-full w-full object-cover" />
                {broken.includes(index) && <span className="absolute inset-x-2 top-2 flex items-center gap-1 rounded-lg bg-[#fff5f1]/95 px-2 py-1 text-[10px] font-bold text-[#a35745]"><AlertCircle size={12} />{t("brokenPhoto")}</span>}
                {index === 0 && <span className="absolute bottom-2 start-2 rounded-full bg-[#102b28]/85 px-2 py-1 text-[10px] font-bold text-white">{t("mainPhoto")}</span>}
              </div>
              <div className="flex items-center justify-between gap-1 p-2">
                <label className="flex cursor-pointer items-center gap-1 rounded-lg px-2 py-1.5 text-[11px] font-bold text-[#0d6b63] hover:bg-[#e4f0ec]">
                  <RefreshCcw size={13} />{t("replacePhoto")}
                  <input type="file" accept={accept} className="sr-only" disabled={uploading} onChange={(event) => { if (event.currentTarget.files) void onUpload(event.currentTarget.files, index); event.currentTarget.value = ""; }} />
                </label>
                <div className="flex items-center gap-0.5">
                  <button type="button" onClick={() => move(index, -1)} disabled={index === 0} className="rounded-lg p-2 text-[#53605b] hover:bg-[#f1f3ef] disabled:opacity-30" aria-label={t("movePhotoUp")}><MoveUp size={14} /></button>
                  <button type="button" onClick={() => move(index, 1)} disabled={index === images.length - 1} className="rounded-lg p-2 text-[#53605b] hover:bg-[#f1f3ef] disabled:opacity-30" aria-label={t("movePhotoDown")}><MoveDown size={14} /></button>
                  <button type="button" onClick={() => { if (window.confirm(t("confirmRemovePhoto"))) { onChange(images.filter((_, photoIndex) => photoIndex !== index)); setBroken([]); } }} className="rounded-lg p-2 text-[#a35745] hover:bg-[#fff5f1]" aria-label={t("removePhoto")}><Trash2 size={14} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------- listing form ----------
function AdminForm({ vehicle, brandSuggestions, locationSuggestions, onSave, onCancel, busy }: { vehicle: Vehicle; brandSuggestions: string[]; locationSuggestions: string[]; onSave: (vehicle: Vehicle) => Promise<void>; onCancel: () => void; busy: boolean }) {
  const { t, optionLabel } = useI18n();
  const initial = useMemo(() => JSON.stringify({ ...vehicle, createdAt: undefined }), [vehicle]);
  const [form, setForm] = useState<Vehicle>(() => ({ ...vehicle, transmission: vehicle.transmission || TRANSMISSION_OPTIONS[0], sellerEmail: vehicle.sellerEmail.trim() }));
  const uploadImage = trpc.vehicle.uploadImage.useMutation();
  const update = <K extends keyof Vehicle>(field: K, value: Vehicle[K]) => setForm((current) => ({ ...current, [field]: value }));
  const dirty = JSON.stringify({ ...form, createdAt: undefined }) !== initial;
  const close = () => { if (!dirty || window.confirm(t("confirmDiscard"))) onCancel(); };

  const uploadFiles = async (filesList: FileList, replaceIndex?: number, field: "images" | "sellerPhoto" = "images") => {
    const files = Array.from(filesList);
    let uploadedCount = 0;
    for (let fileIndex = 0; fileIndex < files.length; fileIndex += 1) {
      const file = files[fileIndex];
      if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type) || file.size > MAX_SOURCE_BYTES) { toast.error(t("imageTooLarge")); continue; }
      try {
        const uploaded = await uploadImage.mutateAsync({ data: await prepareImage(file) });
        uploadedCount += 1;
        if (field === "images") {
          setForm((current) => {
            const images = [...current.images];
            if (replaceIndex !== undefined && fileIndex === 0) images[replaceIndex] = uploaded.url;
            else images.push(uploaded.url);
            return { ...current, images: images.slice(0, 12) };
          });
        } else {
          update("sellerPhoto", uploaded.url);
        }
      } catch {
        toast.error(t("photoUploadFailed"));
      }
    }
    if (uploadedCount > 0) toast.success(t("photoUploaded"));
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.title || !form.brand || !form.model || !form.price || !form.mileage || !form.transmission || !form.description || !form.sellerName || !form.sellerPhone || !form.images.length) { toast.error(t("requiredFields")); return; }
    if (!phoneLooksValid(form.sellerPhone)) { toast.error(t("invalidPhone")); return; }
    if (form.price <= 0) { toast.error(t("invalidPrice")); return; }
    if (form.year < 1886 || form.year > new Date().getFullYear() + 1) { toast.error(t("invalidYear")); return; }
    if (!/\d/.test(form.mileage)) { toast.error(t("invalidMileage")); return; }
    const results = await Promise.all(form.images.map(imageLoads));
    if (results.some((loaded) => !loaded)) { toast.error(t("invalidImage")); return; }
    try {
      await onSave({ ...form, sellerEmail: form.sellerEmail.trim(), id: form.id || `vehicle-${crypto.randomUUID()}` });
    } catch (error) {
      toast.error(errorCode(error) === "CONFLICT" ? t("duplicateListing") : t("saveFailed"));
    }
  };

  const uploading = uploadImage.isPending;
  const models = MODELS_BY_BRAND[form.brand] ?? [];
  return (
    <form onSubmit={handleSubmit} className="rounded-[24px] border border-[#dfe5df] bg-white p-5 shadow-[0_12px_30px_rgba(36,53,48,0.06)] sm:p-7">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#8f5f33]">{vehicle.id ? t("editListing") : t("newListingEyebrow")}</p>
          <h2 className="mt-1 font-display text-2xl font-semibold tracking-[-0.04em] text-[#102b28]">{t("vehicleDetails")}</h2>
        </div>
        <button type="button" onClick={close} className="rounded-full p-2 text-[#66716c] hover:bg-[#f1f3ef]" aria-label={t("closeForm")}><X size={19} /></button>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="sm:col-span-2"><span className="field-label">{t("title")}</span><input className={inputClass} value={form.title} maxLength={300} onChange={(e) => update("title", e.target.value)} placeholder={t("placeholderTitle")} /></label>
        <label><span className="field-label">{t("make")}</span><input className={inputClass} list="brand-list" value={form.brand} maxLength={80} onChange={(e) => update("brand", e.target.value)} placeholder={t("brandPlaceholder")} /><datalist id="brand-list">{brandSuggestions.map((item) => <option key={item} value={item} />)}</datalist></label>
        <label><span className="field-label">{t("model")}</span><input className={inputClass} list="model-list" value={form.model} maxLength={120} onChange={(e) => update("model", e.target.value)} placeholder={t("modelPlaceholder")} /><datalist id="model-list">{models.map((item) => <option key={item} value={item} />)}</datalist></label>
        <label><span className="field-label">{t("year")}</span><input type="number" inputMode="numeric" className={inputClass} value={form.year || ""} onChange={(e) => update("year", Number(e.target.value))} /></label>
        <label><span className="field-label">{t("price")} ({CURRENCY})</span><input type="number" inputMode="numeric" min={1} className={inputClass} value={form.price || ""} onChange={(e) => update("price", Number(e.target.value))} placeholder={t("placeholderPrice")} /></label>
        <label><span className="field-label">{t("mileage")}</span><input className={inputClass} value={form.mileage} maxLength={80} onChange={(e) => update("mileage", e.target.value)} placeholder={t("placeholderMileage")} /></label>
        <label><span className="field-label">{t("location")}</span><input className={inputClass} list="location-list" value={form.location} maxLength={120} onChange={(e) => update("location", e.target.value)} /><datalist id="location-list">{locationSuggestions.map((item) => <option key={item} value={item} />)}</datalist></label>
        <label><span className="field-label">{t("transmission")}</span><select className={`${inputClass} appearance-none`} value={form.transmission} onChange={(e) => update("transmission", e.target.value)}>{TRANSMISSION_OPTIONS.map((item) => <option key={item} value={item}>{optionLabel(item)}</option>)}</select></label>
        <label><span className="field-label">{t("fuel")}</span><select className={`${inputClass} appearance-none`} value={form.fuel} onChange={(e) => update("fuel", e.target.value)}><option value="">{t("optionalField")}</option>{FUEL_OPTIONS.map((item) => <option key={item} value={item}>{optionLabel(item)}</option>)}</select></label>
        <label><span className="field-label">{t("statusLabel")}</span><select className={`${inputClass} appearance-none`} value={form.status} onChange={(e) => update("status", e.target.value as Vehicle["status"])}><option value="available">{t("statusAvailable")}</option><option value="reserved">{t("statusReserved")}</option><option value="sold">{t("statusSold")}</option></select></label>
        <label className="sm:col-span-2"><span className="field-label">{t("description")}</span><textarea className={textareaClass} value={form.description} maxLength={5000} onChange={(e) => update("description", e.target.value)} placeholder={t("descriptionPlaceholder")} /></label>
        <label><span className="field-label">{t("sellerName")}</span><input className={inputClass} value={form.sellerName} maxLength={160} onChange={(e) => update("sellerName", e.target.value)} placeholder={t("placeholderSeller")} /></label>
        <label><span className="field-label">{t("sellerPhone")}</span><input dir="ltr" type="tel" className={inputClass} value={form.sellerPhone} maxLength={80} onChange={(e) => update("sellerPhone", e.target.value)} placeholder={t("placeholderPhone")} /></label>
        <label><span className="field-label">{t("sellerEmail")}</span><input dir="ltr" type="email" className={inputClass} value={form.sellerEmail} maxLength={320} onChange={(e) => update("sellerEmail", e.target.value)} placeholder={t("placeholderEmail")} /></label>
        <div>
          <span className="field-label">{t("sellerPhoto")}</span>
          <input dir="ltr" className={inputClass} value={form.sellerPhoto} maxLength={1000} onChange={(e) => update("sellerPhoto", e.target.value)} placeholder={t("placeholderPhoto")} />
          <label className="mt-2 flex cursor-pointer items-center gap-2 text-xs font-semibold text-[#0d6b63]"><Upload size={14} />{t("uploadSellerPhoto")}<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="sr-only" disabled={uploading} onChange={(event) => { if (event.currentTarget.files) void uploadFiles(event.currentTarget.files, undefined, "sellerPhoto"); event.currentTarget.value = ""; }} /></label>
        </div>
        <PhotoManager images={form.images} onChange={(images) => update("images", images)} onUpload={(files, replaceIndex) => uploadFiles(files, replaceIndex)} uploading={uploading} />
      </div>
      <div className="mt-7 flex flex-col-reverse justify-end gap-3 border-t border-[#edf0eb] pt-5 sm:flex-row">
        <button type="button" onClick={close} className="rounded-xl px-5 py-3 text-sm font-bold text-[#53605b] hover:bg-[#f1f3ef]">{t("cancel")}</button>
        <button type="submit" disabled={busy || uploading} className="flex items-center justify-center gap-2 rounded-xl bg-[#0d6b63] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#09554f] disabled:cursor-not-allowed disabled:opacity-60"><Check size={16} /> {uploading ? t("uploading") : t("saveListing")}</button>
      </div>
    </form>
  );
}

// ---------- dashboard ----------
function downloadJson(data: unknown, fileName: string) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function AdminView() {
  const { t, toggleLanguage, locationLabel, language } = useI18n();
  const { admin, logout } = useAdmin();
  const utils = trpc.useUtils();
  const { data: vehicles = [], isLoading } = trpc.vehicle.list.useQuery();
  const saveMutation = trpc.vehicle.save.useMutation({ onSuccess: () => utils.vehicle.list.invalidate() });
  const deleteMutation = trpc.vehicle.delete.useMutation({ onSuccess: () => utils.vehicle.list.invalidate() });
  const exportQuery = trpc.vehicle.exportCatalogue.useQuery(undefined, { enabled: false });
  const [editing, setEditing] = useState<Vehicle | null>(null);
  const brandSuggestions = useMemo(() => Array.from(new Set([...BRANDS, ...vehicles.map((vehicle) => vehicle.brand)])).sort(), [vehicles]);
  const locationSuggestions = useMemo(() => Array.from(new Set([...LOCATIONS, ...vehicles.map((vehicle) => vehicle.location)])).sort(), [vehicles]);

  const toPayload = (vehicle: Vehicle) => { const { createdAt: _createdAt, ...payload } = vehicle; return payload; };
  const save = async (vehicle: Vehicle) => { await saveMutation.mutateAsync(toPayload(vehicle)); setEditing(null); toast.success(t("listingSaved")); };
  const setStatus = async (vehicle: Vehicle, status: Vehicle["status"]) => {
    try { await saveMutation.mutateAsync({ ...toPayload(vehicle), status }); toast.success(t("listingSaved")); } catch { toast.error(t("saveFailed")); }
  };
  const remove = async (id: string) => {
    if (!window.confirm(t("confirmDelete"))) return;
    try { await deleteMutation.mutateAsync({ id }); toast.success(t("listingDeleted")); } catch { toast.error(t("deleteFailed")); }
  };
  const exportCatalogue = async () => {
    try {
      const result = await exportQuery.refetch();
      if (!result.data) throw new Error("empty");
      downloadJson(result.data, `ridefound-catalogue-${new Date().toISOString().slice(0, 10)}.json`);
      toast.success(t("catalogueExported"));
    } catch { toast.error(t("exportFailed")); }
  };
  const statusText = { available: t("statusAvailable"), reserved: t("statusReserved"), sold: t("statusSold") };

  return (
    <div className="min-h-screen bg-[#f4f6f2] text-[#17221f]">
      <header className="border-b border-[#dfe5df] bg-white">
        <div className="container flex h-[76px] items-center justify-between">
          <Logo />
          <div className="flex items-center gap-2">
            <span className="hidden text-xs text-[#5c6a64] sm:inline">{admin?.email}</span>
            <button onClick={toggleLanguage} className="rounded-full px-3 py-2.5 text-xs font-bold text-[#0d6b63]">{t("language")}</button>
            <Link href="/" className="rounded-full px-4 py-2.5 text-xs font-bold text-[#53605b] hover:bg-[#f1f3ef]">{t("viewPublic")}</Link>
            <button onClick={() => void logout.mutateAsync()} className="rounded-full border border-[#d8ded8] px-4 py-2.5 text-xs font-bold text-[#102b28]">{t("signOut")}</button>
          </div>
        </div>
      </header>
      <main className="container py-10 sm:py-14">
        <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#dcebe5] px-3 py-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-[#0d6b63]"><ShieldCheck size={13} /> {t("adminOnly")}</div>
            <h1 className="font-display text-4xl font-semibold tracking-[-0.055em] text-[#102b28] sm:text-5xl">{t("adminHeading")}</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-[#5c6a64]">{t("adminDescription")}</p>
          </div>
          {!editing && (
            <div className="flex flex-wrap gap-2">
              <button onClick={() => void exportCatalogue()} className="flex items-center gap-2 rounded-xl border border-[#cfdad4] bg-white px-4 py-3 text-sm font-bold text-[#0d6b63] shadow-sm transition hover:border-[#0d6b63]"><Download size={16} /> {t("exportCatalogue")}</button>
              <button onClick={() => setEditing({ ...blankVehicle })} className="flex items-center gap-2 rounded-xl bg-[#102b28] px-4 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-[#0d6b63]"><Plus size={16} /> {t("newListing")}</button>
            </div>
          )}
        </div>
        {editing ? (
          <AdminForm vehicle={editing} brandSuggestions={brandSuggestions} locationSuggestions={locationSuggestions} onSave={save} onCancel={() => setEditing(null)} busy={saveMutation.isPending} />
        ) : (
          <section className="rounded-[24px] border border-[#dfe5df] bg-white shadow-[0_12px_30px_rgba(36,53,48,0.045)]">
            <div className="flex flex-col gap-2 border-b border-[#edf0eb] px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-7">
              <div>
                <h2 className="font-display text-xl font-semibold text-[#102b28]">{t("currentListings")}</h2>
                <p className="mt-1 text-xs text-[#66716c]">{isLoading ? t("loadingCatalogue") : vehicles.length === 1 ? t("vehicleVisibleOne") : t("vehicleVisible", { count: vehicles.length })}</p>
              </div>
              <span className="text-xs font-semibold text-[#66716c]">{t("sharedDatabaseDescription")}</span>
            </div>
            {vehicles.length === 0 && !isLoading ? (
              <div className="px-6 py-20 text-center">
                <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#eef3ee] text-[#5c7a6f]"><CarFront size={25} /></span>
                <h3 className="mt-5 font-display text-2xl font-semibold text-[#102b28]">{t("emptyInventory")}</h3>
                <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#5c6a64]">{t("emptyInventoryDescription")}</p>
                <button onClick={() => setEditing({ ...blankVehicle })} className="mt-6 rounded-full bg-[#0d6b63] px-5 py-3 text-sm font-bold text-white transition hover:bg-[#09554f]">{t("newListing")}</button>
              </div>
            ) : (
              <div className="divide-y divide-[#edf0eb]">
                {vehicles.map((vehicle) => (
                  <div key={vehicle.id} className="flex flex-col gap-4 px-5 py-5 sm:flex-row sm:items-center sm:px-7">
                    <img src={vehicle.images[0]} alt="" loading="lazy" className="h-20 w-28 rounded-xl bg-[#e9e6de] object-cover" />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-lg font-semibold text-[#102b28]">{vehicle.title}</h3>
                        <span className="rounded-full bg-[#eef3ee] px-2 py-1 text-[10px] font-bold uppercase tracking-[0.1em] text-[#0d6b63]">{locationLabel(vehicle.location)}</span>
                      </div>
                      <p className="mt-1 text-sm text-[#5c6a64]">{formatPrice(vehicle.price, language)} · {vehicle.sellerName} · <span dir="ltr" className="inline-block">{vehicle.sellerPhone}</span></p>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <select aria-label={t("statusLabel")} value={vehicle.status} disabled={saveMutation.isPending} onChange={(event) => void setStatus(vehicle, event.currentTarget.value as Vehicle["status"])} className="h-10 rounded-xl border border-[#d8ded8] bg-white px-2 text-xs font-bold text-[#53605b]">
                        {(Object.keys(statusText) as Array<keyof typeof statusText>).map((key) => <option key={key} value={key}>{statusText[key]}</option>)}
                      </select>
                      <button onClick={() => setEditing(vehicle)} className="flex items-center gap-1.5 rounded-xl border border-[#d8ded8] px-3.5 py-2.5 text-xs font-bold text-[#53605b] hover:border-[#0d6b63] hover:text-[#0d6b63]"><Edit3 size={14} /> {t("edit")}</button>
                      <button onClick={() => void remove(vehicle.id)} disabled={deleteMutation.isPending} className="flex items-center gap-1.5 rounded-xl border border-[#ead8d1] px-3.5 py-2.5 text-xs font-bold text-[#a35745] hover:bg-[#fff5f1] disabled:opacity-60"><Trash2 size={14} /> {t("delete")}</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        )}
      </main>
      <footer className="container flex flex-col gap-2 border-t border-[#dfe5df] py-6 text-xs text-[#66716c] sm:flex-row sm:items-center sm:justify-between">
        <span>{t("adminFooter")}</span><Link href="/" className="font-semibold text-[#0d6b63]">{t("backToPublic")}</Link>
      </footer>
    </div>
  );
}

// ---------- sign-in ----------
function LoginForm() {
  const { t } = useI18n();
  const { login } = useAdmin();
  const utils = trpc.useUtils();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    try {
      await login.mutateAsync({ email: email.trim(), password });
      // The password was accepted. If we still are not signed in, the browser refused the session cookie.
      const session = await utils.auth.me.fetch();
      if (!session) setError(t("adminCookieProblem"));
    } catch (caught) {
      const code = errorCode(caught);
      setError(code === "TOO_MANY_REQUESTS" ? t("adminTooMany") : code === "UNAUTHORIZED" ? t("adminLoginFailed") : t("adminServerError"));
    }
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#f4f6f2] px-6">
      <form onSubmit={submit} className="w-full max-w-md rounded-[28px] border border-[#dfe5df] bg-white p-8 shadow-[0_18px_50px_rgba(36,53,48,0.08)]">
        <div className="flex justify-center"><Logo /></div>
        <h1 className="mt-8 text-center font-display text-3xl font-semibold text-[#102b28]">{t("adminLoginTitle")}</h1>
        <p className="mt-3 text-center text-sm leading-6 text-[#5c6a64]">{t("adminLoginDescription")}</p>
        <label className="mt-6 block"><span className="field-label">{t("adminEmail")}</span><input dir="ltr" type="email" autoComplete="username" required className={inputClass} value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label className="mt-4 block"><span className="field-label">{t("adminPassword")}</span><input dir="ltr" type="password" autoComplete="current-password" required className={inputClass} value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        {error && <p role="alert" className="mt-4 rounded-xl bg-[#fff5f1] px-4 py-3 text-sm font-semibold text-[#a35745]">{error}</p>}
        <button type="submit" disabled={login.isPending} className="mt-6 w-full rounded-xl bg-[#102b28] px-5 py-3.5 text-sm font-bold text-white transition hover:bg-[#0d6b63] disabled:opacity-60">{login.isPending ? t("adminSigningIn") : t("adminLoginButton")}</button>
        <Link href="/" className="mt-4 block text-center text-sm font-semibold text-[#0d6b63]">{t("backToPublic")}</Link>
      </form>
    </div>
  );
}

function AdminGate() {
  const { t } = useI18n();
  const { admin, loading } = useAdmin();
  if (loading) return <div className="flex min-h-screen items-center justify-center bg-[#f4f6f2] text-[#53605b]">{t("loadingAdmin")}</div>;
  return admin ? <AdminView /> : <LoginForm />;
}

export function AdminPage() { return <AdminGate />; }
