import { trpc } from "@/lib/trpc";

/** Admin session state. There are no public accounts, only the owner signs in. */
export function useAdmin() {
  const utils = trpc.useUtils();
  const me = trpc.auth.me.useQuery(undefined, { retry: false, refetchOnWindowFocus: false });
  const login = trpc.auth.login.useMutation({ onSuccess: () => utils.auth.me.invalidate() });
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => utils.auth.me.invalidate() });
  return { admin: me.data ?? null, loading: me.isLoading, login, logout };
}
