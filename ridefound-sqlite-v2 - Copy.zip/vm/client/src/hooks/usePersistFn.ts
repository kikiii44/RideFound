import { useRef } from "react";

type Fn<Args extends unknown[], Result> = (...args: Args) => Result;

/** Returns a stable function that always calls the latest version of `fn`. */
export function usePersistFn<Args extends unknown[], Result>(fn: Fn<Args, Result>) {
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const persistRef = useRef<Fn<Args, Result> | null>(null);
  if (!persistRef.current) {
    persistRef.current = (...args) => fnRef.current(...args);
  }
  return persistRef.current;
}
