# Ridefound: vehicle catalogue website

Public catalogue (search, filters, saved cars, a page per car with Call / WhatsApp / Email, English + Arabic) and a
private admin area at `/admin`. **No Manus, no Docker, no database server.** All data lives in one folder: `data/`
(the SQLite database file + uploaded photos).

You need only **Node.js 22.13 or newer** (https://nodejs.org, choose "LTS" or newer) and **pnpm** (installed in step 1).

---

## A. Run it on your computer (to test)

Open a terminal in this folder, then:

```
corepack enable
pnpm install
pnpm setup
pnpm dev
```

- `pnpm setup` asks for your admin email + password and creates the `.env` file for you.
- Open **http://localhost:3000** (the site) and **http://localhost:3000/admin** (sign in with the email/password you chose).
- Windows: if `corepack enable` says "permission denied", open the terminal as Administrator, or run `npm install -g pnpm` instead.
- You may see "SQLite is an experimental feature" in some messages. It is harmless.

Test on your phone: connect it to the same Wi-Fi and open `http://<your-computer-IP>:3000`.

Automatic checks (optional but recommended): `pnpm check` (types), `pnpm test` (tests), `pnpm build` (production build).

## B. Put it online (a small VPS with Ubuntu, any provider, outside Lebanon is more reliable)

1. Point your domain's **A record** to the server's IP address.
2. On the server install Node 22+ (https://nodejs.org), then: `corepack enable`, and `npm install -g pm2`.
3. Copy this folder to the server (for example `/opt/ridefound`) and inside it run:
   ```
   pnpm install
   pnpm setup        # enter your real https address when asked for the website address
   echo "TRUST_PROXY=1" >> .env
   pnpm build
   pm2 start "pnpm start" --name ridefound
   pm2 save && pm2 startup     # run the command it prints, so the site restarts after a reboot
   ```
4. HTTPS: install **Caddy** (https://caddyserver.com/docs/install) and put this in `/etc/caddy/Caddyfile`
   (replace the domain), then `sudo systemctl reload caddy`. Certificates are automatic and free:
   ```
   www.example.com {
       reverse_proxy localhost:3000
   }
   ```
5. Check `https://your-domain/healthz` (should show `{"ok":true}`), then sign in at `/admin` and add a listing.

Update later: copy the new files over, then `pnpm install && pnpm build && pm2 restart ridefound`.
Your `data/` folder and `.env` are never overwritten if you do not copy over them.

Hosting with a persistent disk (Render, Railway, Fly.io...): set `DATABASE_FILE` and `UPLOAD_DIR` in `.env` to paths on
that disk. Without a persistent disk your listings and photos would be erased on every deploy.

## C. Backups (important)

```
pnpm backup
```
Saves the database and photos in `backups/<date>/` (keeps the newest 30). Run it daily with cron, for example
`0 3 * * * cd /opt/ridefound && pnpm backup`, and **copy the `backups` folder off the server** regularly.
To restore: stop the site, copy `backups/<date>/ridefound.db` to `data/ridefound.db` and
`backups/<date>/uploads` to `data/uploads`, then start the site.

## D. Before you go live: checklist

- [ ] `pnpm check`, `pnpm test` and `pnpm build` pass
- [ ] Cities, brands, fuel and transmission lists: `client/src/lib/vehicle-data.ts` (Arabic city names: `locationNames` in `client/src/lib/i18n.tsx`)
- [ ] Replace the homepage hero photo (an Unsplash link in `client/src/pages/Home.tsx`) with your own
- [ ] Review the Privacy page text (`privacy*` keys in `i18n.tsx`) for your situation
- [ ] Add real listings in `/admin` and test every button on a phone, in English and Arabic
- [ ] Daily backups running and copied elsewhere; `/healthz` monitored (e.g. UptimeRobot, free)

## Files you may want to edit

| What | Where |
|---|---|
| Admin email / password / contact email / currency | run `pnpm setup` again (delete `.env` first), then `pnpm build` |
| Text in English and Arabic | `client/src/lib/i18n.tsx` |
| Cities, brands, fuel, transmission | `client/src/lib/vehicle-data.ts` |
| Server settings | `.env` (see `.env.example`) |

## Moving data from the old Manus version
Photos stored on Manus (`/manus-storage/...`) will not load from your server. Download them before leaving Manus and
re-upload them in `/admin` (Edit, then Add photos).

## Security notes
- One admin account; login is rate-limited; the session lasts 7 days in an HTTP-only cookie; cross-site writes are blocked.
- Uploads are checked by their real file type (JPEG, PNG, WebP, GIF only); request sizes are capped.
- Security headers and a content-security policy are set in production. Use a strong admin password, keep the server updated,
  and never share your `.env` file or the `data/` folder.
