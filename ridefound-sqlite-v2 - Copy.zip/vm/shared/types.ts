export type { VehicleStatus } from "./const";
