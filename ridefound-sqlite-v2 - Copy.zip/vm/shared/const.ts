export const VEHICLE_STATUSES = ["available", "reserved", "sold"] as const;
export type VehicleStatus = (typeof VEHICLE_STATUSES)[number];

/** Messages the client compares against. Keep in sync with the server. */
export const UNAUTHED_ERR_MSG = "Please sign in";
export const NOT_ADMIN_ERR_MSG = "You do not have permission to do this";
