import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { ENV } from "./env";
import { detectImage } from "./imageSignature";

import { UPLOAD_URL_PREFIX } from "./uploadPaths";
const SUBDIR = "vehicles";

export function uploadRoot() {
  return path.resolve(ENV.uploadDir);
}

/** Saves an image to disk after checking its real type. Returns the public URL path. */
export async function saveImage(buffer: Buffer): Promise<{ url: string; mime: string }> {
  const detected = detectImage(buffer);
  if (!detected) throw new Error("Unsupported or corrupted image");
  const dir = path.join(uploadRoot(), SUBDIR);
  await fs.mkdir(dir, { recursive: true });
  const name = `${randomUUID()}${detected.ext}`;
  await fs.writeFile(path.join(dir, name), buffer, { flag: "wx" });
  return { url: `${UPLOAD_URL_PREFIX}${SUBDIR}/${name}`, mime: detected.mime };
}

/** Deletes locally stored images. Anything that is not one of our own uploads is ignored. */
export async function deleteStoredImages(urls: string[]) {
  const dir = path.join(uploadRoot(), SUBDIR);
  const pattern = new RegExp(`^${UPLOAD_URL_PREFIX}${SUBDIR}/[A-Za-z0-9-]+\\.(jpg|png|gif|webp)$`);
  for (const url of urls) {
    if (!pattern.test(url)) continue;
    try {
      await fs.unlink(path.join(dir, path.basename(url)));
    } catch {
      /* already gone */
    }
  }
}
