import type { VehicleListItem } from "./db";

export type PageMeta = { title: string; description: string; image?: string; url: string };

export function escapeHtml(value: string) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

const absolute = (base: string, value: string) => (value.startsWith("/") ? `${base}${value}` : value);

/** Fills the <!--SEO--> marker and <title> so link previews (WhatsApp, Facebook, Google) show the listing. */
export function injectMeta(template: string, meta: PageMeta, base: string) {
  const tags = [
    `<meta name="description" content="${escapeHtml(meta.description)}" />`,
    `<link rel="canonical" href="${escapeHtml(meta.url)}" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:site_name" content="Ridefound" />`,
    `<meta property="og:title" content="${escapeHtml(meta.title)}" />`,
    `<meta property="og:description" content="${escapeHtml(meta.description)}" />`,
    `<meta property="og:url" content="${escapeHtml(meta.url)}" />`,
    meta.image ? `<meta property="og:image" content="${escapeHtml(absolute(base, meta.image))}" />` : "",
    `<meta name="twitter:card" content="${meta.image ? "summary_large_image" : "summary"}" />`,
  ].filter(Boolean).join("\n    ");
  return template
    .replace(/<title>[\s\S]*?<\/title>/, `<title>${escapeHtml(meta.title)}</title>`)
    .replace("<!--SEO-->", tags);
}

export function vehicleMeta(vehicle: VehicleListItem, base: string): PageMeta {
  const price = new Intl.NumberFormat("en-US").format(vehicle.price);
  const summary = vehicle.description.replace(/\s+/g, " ").slice(0, 150);
  return {
    title: `${vehicle.title} · Ridefound`,
    description: `${vehicle.year} ${vehicle.brand} ${vehicle.model} · ${price} · ${vehicle.mileage} · ${vehicle.location}. ${summary}`,
    image: vehicle.images[0],
    url: `${base}/car/${encodeURIComponent(vehicle.id)}`,
  };
}

export function buildSitemap(base: string, vehicles: VehicleListItem[]) {
  const urls = [`${base}/`, ...vehicles.map((vehicle) => `${base}/car/${encodeURIComponent(vehicle.id)}`)];
  const body = urls.map((url) => `  <url><loc>${escapeHtml(url)}</loc></url>`).join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${body}\n</urlset>\n`;
}
