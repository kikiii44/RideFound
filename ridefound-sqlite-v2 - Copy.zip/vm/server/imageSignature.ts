export type DetectedImage = { mime: string; ext: string };

/** Identify an image from its first bytes, so a renamed file or lying client cannot sneak in. */
export function detectImage(buffer: Uint8Array): DetectedImage | null {
  const b = buffer;
  if (b.length < 12) return null;
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: "image/jpeg", ext: ".jpg" };
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) {
    return { mime: "image/png", ext: ".png" };
  }
  const ascii = (start: number, end: number) => String.fromCharCode(...Array.from(b.slice(start, end)));
  if (ascii(0, 6) === "GIF87a" || ascii(0, 6) === "GIF89a") return { mime: "image/gif", ext: ".gif" };
  if (ascii(0, 4) === "RIFF" && ascii(8, 12) === "WEBP") return { mime: "image/webp", ext: ".webp" };
  return null;
}
