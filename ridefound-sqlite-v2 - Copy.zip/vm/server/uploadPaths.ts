export const UPLOAD_URL_PREFIX = "/uploads/";
