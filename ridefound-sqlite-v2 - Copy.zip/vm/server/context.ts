import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { readAdminSession } from "./session";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  admin: { email: string } | null;
};

export async function createContext({ req, res }: CreateExpressContextOptions): Promise<TrpcContext> {
  return { req, res, admin: await readAdminSession(req) };
}
