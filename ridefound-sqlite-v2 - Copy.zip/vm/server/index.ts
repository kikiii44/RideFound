import "dotenv/config";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import compression from "compression";
import express from "express";
import fs from "node:fs";
import { createServer } from "node:http";
import path from "node:path";
import { createContext } from "./context";
import { ensureSchema, getVehicle, listVehicles, pingDb } from "./db";
import { assertEnv, ENV } from "./env";
import { appRouter } from "./routers";
import { apiRateLimit, sameOriginWrites, securityHeaders } from "./security";
import { buildSitemap, injectMeta, vehicleMeta, type PageMeta } from "./seo";
import { uploadRoot } from "./storage";

async function main() {
  assertEnv();
  if (ENV.isProduction && !ENV.siteUrl) console.warn("Tip: set SITE_URL in .env (your https address) for correct sitemap and share previews.");
  await ensureSchema();

  const app = express();
  const server = createServer(app);
  app.disable("x-powered-by");
  app.set("trust proxy", ENV.trustProxy);
  app.use(securityHeaders());
  app.use(compression());

  app.get("/healthz", async (_req, res) => {
    try {
      await pingDb();
      res.json({ ok: true });
    } catch {
      res.status(503).json({ ok: false });
    }
  });

  // Uploaded car photos: filenames are random, so they can be cached for a long time.
  fs.mkdirSync(uploadRoot(), { recursive: true });
  app.use(
    "/uploads",
    express.static(uploadRoot(), { index: false, dotfiles: "deny", maxAge: "30d", immutable: true, fallthrough: false }),
  );

  const baseUrl = (req: express.Request) => ENV.siteUrl || `${req.protocol}://${req.get("host")}`;

  app.get("/robots.txt", (req, res) => {
    res.type("text/plain").send(`User-agent: *\nDisallow: /admin\nDisallow: /api/\nSitemap: ${baseUrl(req)}/sitemap.xml\n`);
  });
  app.get("/sitemap.xml", async (req, res) => {
    try {
      res.type("application/xml").send(buildSitemap(baseUrl(req), await listVehicles()));
    } catch {
      res.status(503).end();
    }
  });

  // API: small body limit everywhere except photo uploads.
  const smallBody = express.json({ limit: "200kb" });
  const uploadBody = express.json({ limit: "12mb" });
  app.use("/api", apiRateLimit(), sameOriginWrites());
  app.use("/api/trpc", (req, res, next) => (req.url.includes("vehicle.uploadImage") ? uploadBody : smallBody)(req, res, next));
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
      onError({ error, path: procedure }) {
        if (error.code === "INTERNAL_SERVER_ERROR") console.error(`[tRPC] ${procedure ?? "?"} failed:`, error);
      },
    }),
  );
  app.use("/api", (_req, res) => res.status(404).json({ error: "Not found" }));

  if (!ENV.isProduction) {
    const { setupVite } = await import("./vite");
    await setupVite(app, server);
  } else {
    const publicDir = path.resolve(import.meta.dirname, "public");
    const indexFile = path.join(publicDir, "index.html");
    if (!fs.existsSync(indexFile)) throw new Error(`Build output not found at ${publicDir}. Run "pnpm build" first.`);
    const template = fs.readFileSync(indexFile, "utf-8");

    app.use(
      express.static(publicDir, {
        index: false,
        setHeaders(res, filePath) {
          if (filePath.includes(`${path.sep}assets${path.sep}`)) res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        },
      }),
    );

    app.get("*", async (req, res) => {
      const base = baseUrl(req);
      let meta: PageMeta = {
        title: "Ridefound · Find the car that feels right",
        description: "Ridefound — a calmer way to find a car you’ll be happy to drive home.",
        url: `${base}${req.path === "/" ? "/" : req.path}`,
      };
      let status = 200;
      const match = req.path.match(/^\/car\/([^/]+)\/?$/);
      if (match) {
        try {
          const vehicle = await getVehicle(decodeURIComponent(match[1]));
          if (vehicle) meta = vehicleMeta(vehicle, base);
          else status = 404;
        } catch {
          /* fall back to default meta */
        }
      } else if (req.path !== "/" && !/^\/(admin|privacy)\/?$/.test(req.path)) {
        status = 404;
      }
      if (req.path.startsWith("/admin")) res.setHeader("X-Robots-Tag", "noindex, nofollow");
      res.status(status).set("Cache-Control", "no-cache").type("html").send(injectMeta(template, meta, base));
    });
  }

  server.listen(ENV.port, () => console.log(`Ridefound running on port ${ENV.port} (${ENV.isProduction ? "production" : "development"})`));

  const shutdown = () => server.close(() => process.exit(0));
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
});
