import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import type { VehicleStatus } from "../shared/const";
import { ENV } from "./env";

export type VehiclePayload = {
  id: string;
  title: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  mileage: string;
  transmission: string;
  fuel: string;
  location: string;
  description: string;
  sellerName: string;
  sellerPhone: string;
  sellerEmail: string;
  sellerPhoto: string;
  images: string[];
  status: VehicleStatus;
};

export type VehicleListItem = VehiclePayload & { createdAt: Date };

type Row = Omit<VehiclePayload, "images" | "status"> & { images: string; status: string; createdAt: string };

let _db: DatabaseSync | null = null;

/** One SQLite file, opened once. No database server to install. */
export function getDb(): DatabaseSync {
  if (!_db) {
    const file = ENV.databaseFile;
    if (file !== ":memory:") fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
    _db = new DatabaseSync(file === ":memory:" ? file : path.resolve(file));
    _db.exec("PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA busy_timeout = 5000;");
  }
  return _db;
}

export function closeDb() {
  _db?.close();
  _db = null;
}

export async function pingDb() {
  getDb().prepare("SELECT 1").get();
}

/** Creates the table on first start and adds columns introduced later. Safe to run on every boot. */
export async function ensureSchema() {
  const db = getDb();
  db.exec(`
    CREATE TABLE IF NOT EXISTS vehicles (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      brand TEXT NOT NULL,
      model TEXT NOT NULL,
      year INTEGER NOT NULL,
      price INTEGER NOT NULL,
      mileage TEXT NOT NULL,
      transmission TEXT NOT NULL,
      fuel TEXT NOT NULL DEFAULT '',
      location TEXT NOT NULL,
      description TEXT NOT NULL,
      sellerName TEXT NOT NULL,
      sellerPhone TEXT NOT NULL,
      sellerEmail TEXT NOT NULL DEFAULT '',
      sellerPhoto TEXT NOT NULL DEFAULT '',
      images TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'available',
      createdAt TEXT NOT NULL DEFAULT (datetime('now')),
      updatedAt TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS vehicles_created_idx ON vehicles (createdAt);
  `);
  const columns = db.prepare("PRAGMA table_info(vehicles)").all() as Array<{ name: string }>;
  if (!columns.some((column) => column.name === "status")) {
    db.exec("ALTER TABLE vehicles ADD COLUMN status TEXT NOT NULL DEFAULT 'available'");
  }
}

function normalizeImages(value: string): string[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

function toVehicle(row: Row): VehicleListItem {
  return {
    id: row.id,
    title: row.title,
    brand: row.brand,
    model: row.model,
    year: Number(row.year),
    price: Number(row.price),
    mileage: row.mileage,
    transmission: row.transmission,
    fuel: row.fuel,
    location: row.location,
    description: row.description,
    sellerName: row.sellerName,
    sellerPhone: row.sellerPhone,
    sellerEmail: row.sellerEmail,
    sellerPhoto: row.sellerPhoto,
    images: normalizeImages(row.images),
    status: row.status === "reserved" || row.status === "sold" ? row.status : "available",
    // SQLite stores UTC as "YYYY-MM-DD HH:MM:SS"
    createdAt: new Date(`${row.createdAt.replace(" ", "T")}Z`),
  };
}

export async function listVehicles(): Promise<VehicleListItem[]> {
  const rows = getDb().prepare("SELECT * FROM vehicles ORDER BY createdAt DESC, rowid DESC").all() as unknown as Row[];
  return rows.map(toVehicle);
}

export async function getVehicle(id: string): Promise<VehicleListItem | undefined> {
  const row = getDb().prepare("SELECT * FROM vehicles WHERE id = ?").get(id) as unknown as Row | undefined;
  return row ? toVehicle(row) : undefined;
}

export async function findDuplicateVehicle(vehicle: VehiclePayload) {
  const row = getDb()
    .prepare("SELECT id FROM vehicles WHERE title = ? AND brand = ? AND model = ? AND year = ? AND sellerPhone = ? AND id != ? LIMIT 1")
    .get(vehicle.title, vehicle.brand, vehicle.model, vehicle.year, vehicle.sellerPhone, vehicle.id) as { id: string } | undefined;
  return row;
}

export async function saveVehicle(vehicle: VehiclePayload): Promise<VehiclePayload> {
  getDb()
    .prepare(
      `INSERT INTO vehicles (id, title, brand, model, year, price, mileage, transmission, fuel, location, description,
         sellerName, sellerPhone, sellerEmail, sellerPhoto, images, status)
       VALUES (:id, :title, :brand, :model, :year, :price, :mileage, :transmission, :fuel, :location, :description,
         :sellerName, :sellerPhone, :sellerEmail, :sellerPhoto, :images, :status)
       ON CONFLICT(id) DO UPDATE SET
         title = excluded.title, brand = excluded.brand, model = excluded.model, year = excluded.year,
         price = excluded.price, mileage = excluded.mileage, transmission = excluded.transmission,
         fuel = excluded.fuel, location = excluded.location, description = excluded.description,
         sellerName = excluded.sellerName, sellerPhone = excluded.sellerPhone, sellerEmail = excluded.sellerEmail,
         sellerPhoto = excluded.sellerPhoto, images = excluded.images, status = excluded.status,
         updatedAt = datetime('now')`,
    )
    .run({
      id: vehicle.id,
      title: vehicle.title,
      brand: vehicle.brand,
      model: vehicle.model,
      year: vehicle.year,
      price: vehicle.price,
      mileage: vehicle.mileage,
      transmission: vehicle.transmission,
      fuel: vehicle.fuel,
      location: vehicle.location,
      description: vehicle.description,
      sellerName: vehicle.sellerName,
      sellerPhone: vehicle.sellerPhone,
      sellerEmail: vehicle.sellerEmail,
      sellerPhoto: vehicle.sellerPhoto,
      images: JSON.stringify(vehicle.images),
      status: vehicle.status,
    });
  return vehicle;
}

export async function deleteVehicle(id: string): Promise<void> {
  getDb().prepare("DELETE FROM vehicles WHERE id = ?").run(id);
}
