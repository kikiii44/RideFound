import { randomBytes } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

/**
 * Environment access. Values are read lazily so tests can change process.env.
 * See .env.example for the full list.
 */
const read = (name: string, fallback = "") => (process.env[name] ?? fallback).trim();

export const ENV = {
  get isProduction() { return process.env.NODE_ENV === "production"; },
  get port() { return Number.parseInt(read("PORT", "3000"), 10) || 3000; },
  /** SQLite database file. Everything (database + photos) lives in the ./data folder by default. */
  get databaseFile() { return read("DATABASE_FILE", "./data/ridefound.db"); },
  get jwtSecret() { return resolveJwtSecret(); },
  get adminEmail() { return read("ADMIN_EMAIL").toLowerCase(); },
  get adminPasswordHash() { return read("ADMIN_PASSWORD_HASH"); },
  /** Public URL of the site, e.g. https://www.example.com (used for sitemap and share previews). */
  get siteUrl() { return read("SITE_URL").replace(/\/+$/, ""); },
  get uploadDir() { return read("UPLOAD_DIR", "./data/uploads"); },
  /** Number of reverse proxies in front of the app (Caddy/nginx/Cloudflare = 1). */
  get trustProxy() { return Number.parseInt(read("TRUST_PROXY", "0"), 10) || 0; },
  get sessionDays() { return Number.parseInt(read("SESSION_DAYS", "7"), 10) || 7; },
};

let generatedSecret: string | null = null;

/** Uses JWT_SECRET from .env, otherwise creates one once and keeps it in ./data so sessions survive restarts. */
function resolveJwtSecret() {
  const fromEnv = read("JWT_SECRET");
  if (fromEnv.length >= 32) return fromEnv;
  if (generatedSecret) return generatedSecret;
  const file = path.resolve("./data/jwt-secret.txt");
  try {
    generatedSecret = fs.readFileSync(file, "utf8").trim();
  } catch {
    /* create below */
  }
  if (!generatedSecret || generatedSecret.length < 32) {
    generatedSecret = randomBytes(32).toString("hex");
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, generatedSecret, { mode: 0o600 });
  }
  return generatedSecret;
}

/** Fail fast with a clear message instead of failing later in a confusing way. */
export function assertEnv() {
  const problems: string[] = [];
  if (!ENV.adminEmail) problems.push("ADMIN_EMAIL is missing (run: pnpm setup)");
  if (!ENV.adminPasswordHash.startsWith("scrypt:")) problems.push("ADMIN_PASSWORD_HASH is missing or invalid (run: pnpm setup)");
  if (problems.length) {
    throw new Error(`Configuration problems:\n - ${problems.join("\n - ")}`);
  }
}
