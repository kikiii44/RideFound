import { VEHICLE_STATUSES } from "@shared/const";
import { z } from "zod";
import { UPLOAD_URL_PREFIX } from "./uploadPaths";

function isAllowedImage(value: string) {
  if (value.includes("..")) return false;
  return value.startsWith(UPLOAD_URL_PREFIX) || /^https:\/\//i.test(value);
}

const imageReference = z.string().trim().min(1).max(1000).refine(isAllowedImage, "Photo must be an HTTPS URL or an uploaded photo");

export const vehicleInput = z.object({
  id: z.string().min(1).max(80),
  title: z.string().trim().min(1).max(300),
  brand: z.string().trim().min(1).max(80),
  model: z.string().trim().min(1).max(120),
  year: z.number().int().min(1886).max(new Date().getFullYear() + 1),
  price: z.number().int().min(1).max(100_000_000),
  mileage: z.string().trim().min(1).max(80),
  transmission: z.string().trim().min(1).max(80),
  fuel: z.string().trim().max(80),
  location: z.string().trim().min(1).max(120),
  description: z.string().trim().min(1).max(5000),
  sellerName: z.string().trim().min(1).max(160),
  sellerPhone: z.string().trim().min(1).max(80).refine(
    value => /^\+?[0-9\s().-]+$/.test(value) && value.replace(/\D/g, "").length >= 7,
    "Enter a valid phone number",
  ),
  // Seller email is optional; normalize blank/whitespace-only input to the allowed empty string.
  sellerEmail: z.preprocess(
    value => (typeof value === "string" ? value.trim() : value),
    z.union([z.string().email().max(320), z.literal("")]),
  ),
  sellerPhoto: z.string().trim().max(1000).refine(value => value === "" || isAllowedImage(value), "Seller photo must be an HTTPS URL or an uploaded photo"),
  images: z.array(imageReference).min(1).max(12),
  status: z.enum(VEHICLE_STATUSES).default("available"),
});

