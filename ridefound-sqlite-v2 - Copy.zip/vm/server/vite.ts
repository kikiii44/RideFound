// Development only. Loaded with a dynamic import so production never needs `vite` installed.
import type { Express } from "express";
import fs from "node:fs";
import type { Server } from "node:http";
import path from "node:path";

export async function setupVite(app: Express, server: Server) {
  const { createServer } = await import("vite");
  const { default: viteConfig } = await import("../vite.config");
  const vite = await createServer({
    ...viteConfig,
    configFile: false,
    server: { middlewareMode: true, hmr: { server } },
    appType: "custom",
  });
  app.use(vite.middlewares);
  app.use("*", async (req, res, next) => {
    try {
      const template = await fs.promises.readFile(path.resolve(import.meta.dirname, "..", "client", "index.html"), "utf-8");
      const page = await vite.transformIndexHtml(req.originalUrl, template.replace("<!--SEO-->", ""));
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (error) {
      vite.ssrFixStacktrace(error as Error);
      next(error);
    }
  });
}
