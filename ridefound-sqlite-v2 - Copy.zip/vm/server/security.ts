import type { NextFunction, Request, RequestHandler, Response } from "express";
import { ENV } from "./env";

/** Security headers (a small, dependency-free subset of what `helmet` sets). */
export function securityHeaders(): RequestHandler {
  const csp = [
    "default-src 'self'",
    "img-src 'self' data: blob: https:",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "script-src 'self'",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ].join("; ");
  return (_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
    res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
    if (ENV.isProduction) {
      res.setHeader("Content-Security-Policy", csp);
      res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    }
    next();
  };
}

/**
 * Reject cross-site writes. Browsers always send Origin on cross-site POSTs, so a request whose
 * Origin is not this site is blocked. (Cookies are also SameSite=Lax.)
 */
export function sameOriginWrites(): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.method === "GET" || req.method === "HEAD" || req.method === "OPTIONS") return next();
    const origin = req.headers.origin;
    if (!origin) return next();
    try {
      const host = new URL(origin).host;
      const allowed = new Set([req.headers.host, ENV.siteUrl ? new URL(ENV.siteUrl).host : undefined]);
      if (allowed.has(host)) return next();
    } catch {
      /* fall through */
    }
    res.status(403).json({ error: "Cross-site request blocked" });
  };
}

/** Small in-memory sliding-window limiter. Fine for a single-process site. */
export function createLimiter(options: { windowMs: number; max: number }) {
  const hits = new Map<string, number[]>();
  const timer = setInterval(() => {
    const cutoff = Date.now() - options.windowMs;
    for (const [key, times] of hits) {
      const recent = times.filter((time) => time > cutoff);
      if (recent.length) hits.set(key, recent);
      else hits.delete(key);
    }
  }, Math.min(options.windowMs, 60_000));
  timer.unref?.();
  return {
    /** Returns true when the request is allowed and records it. */
    take(key: string): boolean {
      const now = Date.now();
      const recent = (hits.get(key) ?? []).filter((time) => time > now - options.windowMs);
      if (recent.length >= options.max) {
        hits.set(key, recent);
        return false;
      }
      recent.push(now);
      hits.set(key, recent);
      return true;
    },
    reset(key: string) {
      hits.delete(key);
    },
  };
}

export function apiRateLimit(): RequestHandler {
  const limiter = createLimiter({ windowMs: 60_000, max: 300 });
  return (req, res, next) => {
    if (limiter.take(req.ip ?? "unknown")) return next();
    res.status(429).json({ error: "Too many requests" });
  };
}
