import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { deleteVehicle, findDuplicateVehicle, getVehicle, listVehicles, pingDb, saveVehicle, type VehiclePayload } from "./db";
import { ENV } from "./env";
import { verifyPassword } from "./password";
import { createLimiter } from "./security";
import { clearAdminCookie, createAdminToken, setAdminCookie } from "./session";
import { deleteStoredImages, saveImage } from "./storage";
import { adminProcedure, publicProcedure, router } from "./trpc";
import { vehicleInput } from "./vehicleSchema";

const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;

const loginLimiter = createLimiter({ windowMs: 15 * 60_000, max: 8 });

export const appRouter = router({
  health: publicProcedure.query(async () => {
    await pingDb();
    return { ok: true } as const;
  }),
  auth: router({
    me: publicProcedure.query(({ ctx }) => (ctx.admin ? { email: ctx.admin.email } : null)),
    login: publicProcedure
      .input(z.object({ email: z.string().trim().min(1).max(320), password: z.string().min(1).max(200) }))
      .mutation(async ({ input, ctx }) => {
        const key = ctx.req.ip ?? "unknown";
        if (!loginLimiter.take(key)) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again later." });
        }
        // Always run the (slow) password check so timing does not reveal whether the email matched.
        const passwordOk = verifyPassword(input.password, ENV.adminPasswordHash);
        const emailOk = input.email.toLowerCase() === ENV.adminEmail;
        if (!passwordOk || !emailOk) {
          console.warn(`[auth] Failed admin login from ${key}: ${!emailOk ? "email does not match ADMIN_EMAIL" : "password does not match ADMIN_PASSWORD_HASH"}`);
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Incorrect email or password." });
        }
        loginLimiter.reset(key);
        setAdminCookie(ctx.req, ctx.res, await createAdminToken(ENV.adminEmail));
        return { email: ENV.adminEmail };
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      clearAdminCookie(ctx.req, ctx.res);
      return { success: true } as const;
    }),
  }),
  vehicle: router({
    list: publicProcedure.query(() => listVehicles()),
    get: publicProcedure.input(z.object({ id: z.string().min(1).max(80) })).query(async ({ input }) => (await getVehicle(input.id)) ?? null),
    save: adminProcedure.input(vehicleInput).mutation(async ({ input }) => {
      const vehicle = input as VehiclePayload;
      const duplicate = await findDuplicateVehicle(vehicle);
      if (duplicate) {
        throw new TRPCError({ code: "CONFLICT", message: "A matching vehicle listing already exists." });
      }
      const previous = await getVehicle(vehicle.id);
      const saved = await saveVehicle(vehicle);
      if (previous) {
        const kept = new Set([...vehicle.images, vehicle.sellerPhoto]);
        await deleteStoredImages([...previous.images, previous.sellerPhoto].filter(url => url && !kept.has(url)));
      }
      return saved;
    }),
    delete: adminProcedure.input(z.object({ id: z.string().min(1).max(80) })).mutation(async ({ input }) => {
      const previous = await getVehicle(input.id);
      await deleteVehicle(input.id);
      if (previous) await deleteStoredImages([...previous.images, previous.sellerPhoto]);
    }),
    exportCatalogue: adminProcedure.query(() => listVehicles()),
    uploadImage: adminProcedure
      .input(z.object({ data: z.string().min(1).max(12_000_000) }))
      .mutation(async ({ input }) => {
        const buffer = Buffer.from(input.data, "base64");
        if (buffer.byteLength > MAX_UPLOAD_BYTES) {
          throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Photo must be 8 MB or smaller." });
        }
        try {
          const { url } = await saveImage(buffer);
          return { url };
        } catch {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Please upload a JPEG, PNG, WebP or GIF image." });
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
