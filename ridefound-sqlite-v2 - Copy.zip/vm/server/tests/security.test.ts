import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "../password";
import { detectImage } from "../imageSignature";
import { createLimiter } from "../security";
import { escapeHtml, injectMeta } from "../seo";

describe("password hashing", () => {
  it("accepts the right password and rejects others", () => {
    const hash = hashPassword("correct horse battery");
    expect(hash.startsWith("scrypt:")).toBe(true);
    expect(verifyPassword("correct horse battery", hash)).toBe(true);
    expect(verifyPassword("wrong password", hash)).toBe(false);
  });
  it("rejects malformed hashes instead of throwing", () => {
    expect(verifyPassword("x", "")).toBe(false);
    expect(verifyPassword("x", "scrypt:1:2")).toBe(false);
    expect(verifyPassword("x", "md5:a:b:c:d:e")).toBe(false);
  });
});

describe("image signature check", () => {
  const pad = (bytes: number[]) => Uint8Array.from([...bytes, ...new Array(16).fill(0)]);
  it("recognises real image headers", () => {
    expect(detectImage(pad([0xff, 0xd8, 0xff, 0xe0]))?.mime).toBe("image/jpeg");
    expect(detectImage(pad([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))?.mime).toBe("image/png");
    expect(detectImage(pad([...Buffer.from("GIF89a")]))?.mime).toBe("image/gif");
    expect(detectImage(Uint8Array.from([...Buffer.from("RIFF"), 0, 0, 0, 0, ...Buffer.from("WEBP")]))?.mime).toBe("image/webp");
  });
  it("rejects scripts and svg disguised as images", () => {
    expect(detectImage(Buffer.from("<svg xmlns='http://www.w3.org/2000/svg'></svg>"))).toBeNull();
    expect(detectImage(Buffer.from("<?php echo 1; ?>   padding padding"))).toBeNull();
    expect(detectImage(Buffer.from("tiny"))).toBeNull();
  });
});

describe("rate limiter", () => {
  it("blocks after the limit and can be reset", () => {
    const limiter = createLimiter({ windowMs: 60_000, max: 3 });
    expect([1, 2, 3].map(() => limiter.take("ip"))).toEqual([true, true, true]);
    expect(limiter.take("ip")).toBe(false);
    expect(limiter.take("other")).toBe(true);
    limiter.reset("ip");
    expect(limiter.take("ip")).toBe(true);
  });
});

describe("share-preview helper", () => {
  it("escapes user text so listings cannot inject HTML", () => {
    expect(escapeHtml(`<script>"x"&'y'</script>`)).not.toContain("<");
    const html = injectMeta(
      "<html><head><title>x</title><!--SEO--></head></html>",
      { title: `A"><script>alert(1)</script>`, description: "d", url: "https://e.com/car/1", image: "/uploads/vehicles/a.jpg" },
      "https://e.com",
    );
    expect(html).not.toContain("<script>");
    expect(html).toContain('content="https://e.com/uploads/vehicles/a.jpg"');
  });
});
