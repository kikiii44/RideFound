import { describe, expect, it } from "vitest";
import { vehicleInput } from "../vehicleSchema";

const valid = {
  id: "vehicle-1", title: "Demo vehicle", brand: "Volvo", model: "XC60", year: 2021, price: 25000,
  mileage: "40,000 km", transmission: "Automatic", fuel: "", location: "Amsterdam",
  description: "A demo vehicle with complete details.", sellerName: "Demo seller", sellerPhone: "+961 3 123 456",
  sellerEmail: "   ", sellerPhoto: "", images: ["https://example.com/car.jpg"],
};

describe("vehicle input validation", () => {
  it("accepts blank optional fields and defaults status to available", () => {
    const parsed = vehicleInput.parse(valid);
    expect(parsed.sellerEmail).toBe("");
    expect(parsed.status).toBe("available");
  });
  it("accepts our own uploaded photos but not http, javascript: or path tricks", () => {
    expect(vehicleInput.safeParse({ ...valid, images: ["/uploads/vehicles/abc.webp"] }).success).toBe(true);
    for (const bad of ["http://example.com/a.jpg", "javascript:alert(1)", "/uploads/../secret.png", "data:image/png;base64,AAAA"]) {
      expect(vehicleInput.safeParse({ ...valid, images: [bad] }).success).toBe(false);
    }
  });
  it("rejects unsafe phone, price, year and status values", () => {
    for (const patch of [{ sellerPhone: "not-a-phone" }, { price: 0 }, { year: 2200 }, { status: "hacked" }]) {
      expect(vehicleInput.safeParse({ ...valid, ...patch }).success).toBe(false);
    }
  });
});
