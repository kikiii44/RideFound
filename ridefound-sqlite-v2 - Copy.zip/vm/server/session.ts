import { parse as parseCookies } from "cookie";
import type { Request, Response } from "express";
import { SignJWT, jwtVerify } from "jose";
import { ENV } from "./env";

export const SESSION_COOKIE = "rf_admin";

const key = () => new TextEncoder().encode(ENV.jwtSecret);

export async function createAdminToken(email: string): Promise<string> {
  return new SignJWT({ role: "admin", email })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setSubject("admin")
    .setIssuedAt()
    .setExpirationTime(`${ENV.sessionDays}d`)
    .sign(key());
}

export async function readAdminSession(req: Request): Promise<{ email: string } | null> {
  const token = parseCookies(req.headers.cookie ?? "")[SESSION_COOKIE];
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, key(), { algorithms: ["HS256"] });
    if (payload.sub !== "admin" || payload.role !== "admin" || typeof payload.email !== "string") return null;
    // If the admin email is changed in the environment, old sessions stop working.
    if (payload.email.toLowerCase() !== ENV.adminEmail) return null;
    return { email: payload.email };
  } catch {
    return null;
  }
}

/** Secure cookies only work over https, so decide from the actual request (never from SITE_URL alone). */
export function isSecureRequest(req: Pick<Request, "secure" | "headers">) {
  if (req.secure) return true;
  try {
    const site = ENV.siteUrl ? new URL(ENV.siteUrl) : null;
    return Boolean(site && site.protocol === "https:" && site.host === req.headers.host);
  } catch {
    return false;
  }
}

function cookieOptions(req: Request) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: isSecureRequest(req),
    path: "/",
  };
}

export function setAdminCookie(req: Request, res: Response, token: string) {
  res.cookie(SESSION_COOKIE, token, { ...cookieOptions(req), maxAge: ENV.sessionDays * 24 * 60 * 60 * 1000 });
}

export function clearAdminCookie(req: Request, res: Response) {
  res.clearCookie(SESSION_COOKIE, cookieOptions(req));
}
